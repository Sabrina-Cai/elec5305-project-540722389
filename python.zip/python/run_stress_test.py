"""Stress test: a loud, low-frequency broadband noise episode (e.g. a passing boat) in the middle of
a long song. Does a local / whitened noise floor cope better than one global floor?"""
import sys, numpy as np
sys.path.insert(0, '.')
import whale_pipeline as wp, long_recording as lr
from scipy import signal
fs = 8000
x, gt = lr.gen_long_synthetic(snrs=(20, 15, 12, 20, 15, 12, 20, 15), seed=10)
dur = len(x) / fs
rng = np.random.default_rng(1)
# boat: 90 s of band-limited (60-900 Hz) noise whose level rises and falls, centred at 40% of the file
a, b = int(0.40 * dur * fs), int(0.40 * dur * fs) + 90 * fs
sos = signal.butter(4, [60, 900], 'bandpass', fs=fs, output='sos')
boat = signal.sosfilt(sos, rng.standard_normal(b - a))
env = np.sin(np.pi * np.linspace(0, 1, b - a)) ** 2
level = 0.35 * np.std(x[:fs * 10])      # boat noise peak vs overall level; sweep below
y_all = {}
for gain_db in (0, 6, 12):
    xx = x.copy(); xx[a:b] += boat / boat.std() * env * level * 10 ** (gain_db / 20) * 2
    y_all[gain_db] = wp.preprocess(xx, fs)
band = (100., 1500.)
print('F1 inside the boat episode (and over the whole file) -- thresholds 4/8 dB; 6/10 dB')
for g, y in y_all.items():
    t0, t1 = a / fs, b / fs
    gi = gt[(gt[:, 0] >= t0) & (gt[:, 1] <= t1)]
    for lo, hi in [(4, 8), (6, 10)]:
        out = []
        for n, fn in (('global', lr.envelope_global), ('local', lr.envelope_local), ('whitened', lr.envelope_whitened)):
            t, e = fn(y, fs, band); d = lr.detect_envelope(t, e, lo, hi)
            di = d[(d[:, 0] >= t0) & (d[:, 1] <= t1)]
            ri = wp.evaluate(di, gi)[0]; rw = wp.evaluate(d, gt)[0]
            out.append(f'{n}: in {ri["f1"]:.2f} (P {ri["precision"]:.2f} R {ri["recall"]:.2f}) all {rw["f1"]:.2f}')
        print(f'  boat +{g:2d} dB, {lo}/{hi}:  ' + ' | '.join(out))
