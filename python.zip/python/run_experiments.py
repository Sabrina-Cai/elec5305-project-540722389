import json, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import signal
from scipy.io import wavfile
sys.path.insert(0, os.path.dirname(__file__))
import whale_pipeline as wp

OUT = os.path.join(os.path.dirname(__file__), '..', 'results')
fs = wp.P['fs']
CB = dict(blue='#0072B2', orange='#E69F00', green='#009E73', red='#D55E00', purple='#CC79A7', grey='#666666')

DETECTORS = {
    'Single threshold (broadband)': dict(method='single', band=None),
    'Double threshold (broadband)': dict(method='double', band=None),
    'Double threshold (100-1500 Hz)': dict(method='double', band=wp.P['narrow_band']),
}
REPS = ['mfcc_mean', 'mfcc_mean_std_dur', 'centroid_bw_dur', 'spec_corr']

# ---- 1. export synthetic files so the MATLAB scripts use identical data -----------------
for snr in [20, 10, 5, 0]:
    x, gt = wp.gen_synthetic_song(snr_db=snr, seed=0, fs=fs)
    wavfile.write(f'{OUT}/synth_snr{snr:02d}.wav', fs, (x * 32767).astype(np.int16))
    np.savetxt(f'{OUT}/synth_snr{snr:02d}_gt.csv', gt, delimiter=',', header='onset_s,offset_s,type', comments='', fmt='%.4f,%.4f,%d')

# ---- 2. baseline run at SNR = 10 dB (figures + unit table) -------------------------------
x, gt = wp.gen_synthetic_song(snr_db=10, seed=0, fs=fs)
y = wp.preprocess(x, fs)
det, (t, e, floor) = wp.detect(y, fs, 'double')
res, match = wp.evaluate(det, gt)
print('BASELINE (double threshold, broadband, SNR 10 dB):', {k: round(v, 3) for k, v in res.items()})
print('n GT units', len(gt), ' n detections', len(det))

fig, ax = plt.subplots(3, 1, figsize=(11, 8), sharex=True, gridspec_kw=dict(height_ratios=[1, 2, 1.4]))
tt = np.arange(x.size) / fs
ax[0].plot(tt, y, lw=.3, color=CB['grey']); ax[0].set_ylabel('Amplitude'); ax[0].set_title('Synthetic humpback-like song, SNR 10 dB (band-passed)')
f, ts, S = signal.spectrogram(y, fs, nperseg=wp.P['nfft'], noverlap=wp.P['nfft'] - wp.P['hop'])
ax[1].pcolormesh(ts, f, 10 * np.log10(S + 1e-12), shading='auto', cmap='viridis', vmin=-90, vmax=-40)
ax[1].set_ylim(0, 2500); ax[1].set_ylabel('Frequency (Hz)')
for g in gt: ax[1].plot([g[0], g[1]], [2380, 2380], color='white', lw=4, solid_capstyle='butt')
for d in det: ax[1].plot([d[0], d[1]], [2200, 2200], color=CB['orange'], lw=4, solid_capstyle='butt')
ax[1].text(69, 2380, 'ground truth', color='white', fontsize=8, va='center', ha='left', clip_on=False, backgroundcolor='#444444')
ax[1].text(69, 2200, 'detected', color=CB['orange'], fontsize=8, va='center', ha='left', clip_on=False, backgroundcolor='#444444')
ax[2].plot(t, e, color=CB['blue'], lw=1)
ax[2].axhline(floor, color=CB['grey'], ls=':', label='noise floor (20th pct)')
ax[2].axhline(floor + wp.P['low_db'], color=CB['green'], ls='--', label='low threshold')
ax[2].axhline(floor + wp.P['high_db'], color=CB['red'], ls='--', label='high threshold')
ax[2].set_ylabel('Band energy (dB)'); ax[2].set_xlabel('Time (s)'); ax[2].legend(ncol=3, fontsize=8, loc='upper right')
plt.tight_layout(); plt.savefig(f'{OUT}/fig1_segmentation_baseline.png', dpi=160); plt.close()

# ---- 3. detector comparison vs SNR (5 seeds) ----------------------------------------------
snrs = [20, 15, 10, 5, 0, -3]; seeds = range(5)
det_f1 = {k: np.zeros((len(snrs), len(seeds))) for k in DETECTORS}
det_stats = {k: [] for k in DETECTORS}
for i, snr in enumerate(snrs):
    for j, sd in enumerate(seeds):
        x, gt = wp.gen_synthetic_song(snr_db=snr, seed=sd, fs=fs)
        for name, cfg in DETECTORS.items():
            lo, hi = (cfg['band'] or (wp.P['bp_lo'], wp.P['bp_hi']))
            y = wp.preprocess(x, fs)
            d, _ = wp.detect(y, fs, cfg['method'], cfg['band'])
            r, _ = wp.evaluate(d, gt)
            det_f1[name][i, j] = r['f1']
            if snr == 10: det_stats[name].append(r)
print('\nDETECTOR COMPARISON (mean F1 over 5 seeds):')
print('SNR   ' + '  '.join(f'{n[:30]:>30s}' for n in DETECTORS))
for i, snr in enumerate(snrs):
    print(f'{snr:4d}  ' + '  '.join(f'{det_f1[n][i].mean():30.3f}' for n in DETECTORS))
print('\nAt SNR 10 dB (mean over seeds): precision / recall / onset err ms / offset err ms')
for n, rs in det_stats.items():
    print(f'  {n:34s}', *(f'{np.nanmean([r[k] for r in rs]):7.3f}' for k in ['precision', 'recall', 'onset_err_ms', 'offset_err_ms']))

fig, ax = plt.subplots(figsize=(6.5, 4))
for (name, M), c in zip(det_f1.items(), [CB['grey'], CB['blue'], CB['orange']]):
    ax.errorbar(snrs, M.mean(1), yerr=M.std(1), marker='o', capsize=3, label=name, color=c)
ax.set_xlabel('SNR (dB)'); ax.set_ylabel('Segmentation F1 (IoU ≥ 0.5)'); ax.set_ylim(0, 1.05)
ax.invert_xaxis(); ax.legend(fontsize=8); ax.set_title('Detector comparison, synthetic song (5 seeds)')
ax.grid(alpha=.3); plt.tight_layout(); plt.savefig(f'{OUT}/fig2_detector_vs_snr.png', dpi=160); plt.close()

# ---- 4. unit similarity: representations vs clustering agreement -------------------------
ari_tab = {r: np.zeros((len(snrs), len(seeds))) for r in REPS}
for i, snr in enumerate(snrs):
    for j, sd in enumerate(seeds):
        x, gt = wp.gen_synthetic_song(snr_db=snr, seed=sd, fs=fs)
        y = wp.preprocess(x, fs)
        d, _ = wp.detect(y, fs, 'double', wp.P['narrow_band'])
        _, m = wp.evaluate(d, gt)
        if len(m) < 8:
            for r in REPS: ari_tab[r][i, j] = np.nan
            continue
        di = [a for a, b in m]; truth = gt[[b for a, b in m], 2].astype(int)
        R = wp.unit_representations(y, fs, d[di])
        for r in REPS:
            ari_tab[r][i, j] = wp.ari(wp.cluster(wp.distance_matrix(r, R[r]), 4), truth)
print('\nCLUSTERING ARI vs true unit type (k=4, average linkage, mean over seeds):')
print('SNR   ' + '  '.join(f'{r:>18s}' for r in REPS))
for i, snr in enumerate(snrs):
    print(f'{snr:4d}  ' + '  '.join(f'{np.nanmean(ari_tab[r][i]):18.3f}' for r in REPS))

fig, ax = plt.subplots(figsize=(6.5, 4))
for r, c in zip(REPS, [CB['blue'], CB['orange'], CB['green'], CB['purple']]):
    ax.errorbar(snrs, np.nanmean(ari_tab[r], 1), yerr=np.nanstd(ari_tab[r], 1), marker='o', capsize=3, label=r, color=c)
ax.set_xlabel('SNR (dB)'); ax.set_ylabel('Adjusted Rand index'); ax.invert_xaxis(); ax.set_ylim(-0.1, 1.05)
ax.legend(fontsize=8); ax.grid(alpha=.3); ax.set_title('Unit-similarity representations vs true unit type')
plt.tight_layout(); plt.savefig(f'{OUT}/fig3_similarity_vs_snr.png', dpi=160); plt.close()

# ---- 5. similarity matrices + n-gram extension at SNR 10 ---------------------------------
x, gt = wp.gen_synthetic_song(snr_db=10, seed=0, fs=fs)
y = wp.preprocess(x, fs)
d, _ = wp.detect(y, fs, 'double', wp.P['narrow_band'])
rr, m = wp.evaluate(d, gt)
print('\nBand-limited double-threshold at 10 dB:', {k: round(v, 3) for k, v in rr.items()})
order = sorted(m, key=lambda p: p[0]); di = [a for a, b in order]; truth = gt[[b for a, b in order], 2].astype(int)
R = wp.unit_representations(y, fs, d[di])
fig, ax = plt.subplots(1, 2, figsize=(10, 4.4))
idx = np.argsort(truth, kind='stable')
for a, r, ttl in zip(ax, ['mfcc_mean_std_dur', 'spec_corr'], ['MFCC mean+std+duration (Euclid.)', 'Spectrogram correlation (1 - r)']):
    D = wp.distance_matrix(r, R[r]); im = a.imshow(D[np.ix_(idx, idx)], cmap='magma_r'); a.set_title(ttl, fontsize=10)
    bnd = np.flatnonzero(np.diff(truth[idx])) + .5
    for bb in bnd: a.axhline(bb, color='white', lw=.8); a.axvline(bb, color='white', lw=.8)
    a.set_xlabel('unit (sorted by true type A,B,C,D)'); plt.colorbar(im, ax=a, fraction=.046)
plt.tight_layout(); plt.savefig(f'{OUT}/fig4_similarity_matrices.png', dpi=160); plt.close()

labels = wp.cluster(wp.distance_matrix('mfcc_mean_std_dur', R['mfcc_mean_std_dur']), 4)
print('ARI (MFCC mean+std+dur):', round(wp.ari(labels, truth), 3))
# map cluster -> letter by majority true type
sym = np.array([chr(65 + int(np.bincount(truth[labels == c]).argmax())) for c in labels])
seq = ''.join(sym[np.argsort(np.array(di))])
print('Symbol sequence:', seq)
print('Top 4-grams:', wp.top_ngrams(list(seq), 4, 4), '  (true theme 1 = ABAC, theme 2 = DDCB)')
json.dump(dict(baseline=res), open(f'{OUT}/baseline_metrics.json', 'w'), indent=1)
