"""
Extensions for a LONG recording (e.g. the 25 min NIPS4B humpback file).

Ideas taken from the Pace (2013) thesis discussion (Sec. 4.4 and 9.2):
  * a fixed, hand-set noise floor / threshold per recording is the main weakness of the
    double-threshold detector -> estimate the floor LOCALLY and per frequency bin
    (a simple pre-whitening; Pace points to pre-whitening and to Helble et al. 2012);
  * missed or merged units shift the whole symbol sequence ("frame-shift error") ->
    evaluate on the SEQUENCE too, and measure repetition of the unit sequence.
Everything is my own implementation from those descriptions; parameters are in LP.
"""
import numpy as np
from scipy import signal
from scipy.ndimage import uniform_filter1d, percentile_filter
import whale_pipeline as wp

LP = dict(
    floor_win_s=60.0,      # window over which the noise floor is estimated
    floor_pct=15,          # low percentile of each frequency bin = noise floor
    low_snr=6.0,           # hysteresis thresholds, dB above the local floor
    high_snr=10.0,
)


def _spec(x, fs, band):
    f, t, S = signal.spectrogram(x, fs, window='hann', nperseg=wp.P['nfft'],
                                 noverlap=wp.P['nfft'] - wp.P['hop'], mode='psd')
    m = (f >= band[0]) & (f <= band[1])
    return t, S[m]


def _smooth(e):
    n = max(1, int(round(wp.P['smooth_s'] * wp.P['fs'] / wp.P['hop'])))
    return uniform_filter1d(e, n, mode='nearest')


def _local_floor(A, frames_per_s, win_s, pct):
    """Rolling low percentile along time (axis -1), computed on a coarse grid and interpolated."""
    n = A.shape[-1]
    step = max(1, int(win_s * frames_per_s / 4))          # 4 estimates per window
    centres = np.arange(0, n, step)
    half = int(win_s * frames_per_s / 2)
    vals = np.stack([np.percentile(A[..., max(0, c - half):c + half + 1], pct, axis=-1) for c in centres], -1)
    return np.stack([np.interp(np.arange(n), centres, v) for v in vals.reshape(-1, len(centres))]).reshape(A.shape)


def envelope_global(x, fs, band):
    """The current method: dB band energy, one global floor (percentile of the whole clip)."""
    t, S = _spec(x, fs, band)
    e = _smooth(10 * np.log10(S.sum(0) + 1e-12))
    return t, e - np.percentile(e, wp.P['floor_pct'])


def envelope_local(x, fs, band, win_s=None, pct=None):
    """Band energy in dB minus a ROLLING floor (low percentile over a window)."""
    win_s = win_s or LP['floor_win_s']; pct = pct or LP['floor_pct']
    t, S = _spec(x, fs, band)
    e = _smooth(10 * np.log10(S.sum(0) + 1e-12))
    fps = 1.0 / (t[1] - t[0])
    return t, e - _local_floor(e, fps, win_s, pct)


def envelope_whitened(x, fs, band, win_s=None, pct=None):
    """Per-frequency-bin floor (rolling low percentile) divides the power first, so coloured
    noise and ship hum are flattened; the envelope is the mean in-band SNR in dB."""
    win_s = win_s or LP['floor_win_s']; pct = pct or LP['floor_pct']
    t, S = _spec(x, fs, band)
    fps = 1.0 / (t[1] - t[0])
    floor = _local_floor(S, fps, win_s, pct)
    snr = S / (floor + 1e-20)
    e = _smooth(10 * np.log10(snr.mean(0) + 1e-12))
    # the low percentile of exponential-distributed power sits below the mean: remove that offset
    # using the median of the lowest-energy frames
    return t, e - np.percentile(e, 15)


def detect_envelope(t, e, low, high):
    """Hysteresis detector on an envelope that is already expressed in dB above the floor."""
    s, en = wp._runs(e > low)
    keep = [i for i, (a, b) in enumerate(zip(s, en)) if np.any(e[a:b + 1] > high)]
    return wp._postprocess(s[keep], en[keep], t)


# ----------------------------------------------------------------- long synthetic test song
def gen_long_synthetic(snrs=(20, 12, 6, 15, 8, 20, 10, 5), seed=0, fs=8000):
    """Concatenate songs with different SNR (singer drifting nearer / further, boat noise
    changing) so one global floor cannot suit them all. Returns x, gt (onset, offset, type)."""
    xs, gts, t0 = [], [], 0.0
    for i, snr in enumerate(snrs):
        x, gt = wp.gen_synthetic_song(snr_db=snr, seed=seed + i, fs=fs)
        x = x / np.max(np.abs(x))
        gain = 10 ** (np.random.default_rng(100 + i).uniform(-6, 0) / 20)   # level changes between sections
        xs.append(x * gain)
        g = gt.copy(); g[:, :2] += t0; gts.append(g)
        t0 += x.size / fs
    return np.concatenate(xs), np.vstack(gts)


# ----------------------------------------------------------------- label-free analysis of the units
def cluster_stability(F_name, F, k, reps=30, frac=0.8, seed=0):
    """Bootstrap stability of a clustering WITHOUT labels: recluster random 80% subsets and
    compare with the full clustering on the shared units (mean ARI). 1 = perfectly stable."""
    rng = np.random.default_rng(seed)
    D = wp.distance_matrix(F_name, F)
    full = wp.cluster(D, k)
    sc = []
    n = len(F)
    for _ in range(reps):
        idx = np.sort(rng.choice(n, int(frac * n), replace=False))
        sub = wp.cluster(D[np.ix_(idx, idx)], k)
        sc.append(wp.ari(sub, full[idx]))
    return float(np.mean(sc)), float(np.std(sc))


def repetition_profile(labels, max_lag=40):
    """For each lag L (in units): fraction of positions where label[i] == label[i+L].
    Peaks at the phrase / theme length. Compare with a shuffled sequence for chance level."""
    s = np.asarray(labels)
    prof = np.array([np.mean(s[:-L] == s[L:]) if len(s) > L else np.nan for L in range(1, max_lag + 1)])
    rng = np.random.default_rng(0)
    chance = np.mean([[np.mean(sh[:-L] == sh[L:]) for L in range(1, max_lag + 1)]
                      for sh in (rng.permutation(s) for _ in range(50))], axis=0)
    return prof, chance


def sequence_edit_distance(a, b):
    """Levenshtein distance between two symbol sequences (normalised by the longer one).
    Used to score how well the detected unit sequence matches the annotated one; a single missed
    unit costs 1 here, while for position-by-position comparison it would shift everything."""
    a, b = list(a), list(b)
    d = np.arange(len(b) + 1)
    for i in range(1, len(a) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(b) + 1):
            cur = d[j]
            d[j] = min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] != b[j - 1]))
            prev = cur
    return d[len(b)] / max(len(a), len(b), 1)
