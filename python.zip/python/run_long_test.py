"""Test the long-recording extensions on a LONG SYNTHETIC song (8 sections, ~9 min, SNR 5-20 dB)."""
import sys, numpy as np
sys.path.insert(0, '.')
import whale_pipeline as wp
import long_recording as lr

fs = 8000
x, gt = lr.gen_long_synthetic()
y = wp.preprocess(x, fs)
dur = len(y) / fs
print(f'long synthetic: {dur/60:.1f} min, {len(gt)} annotated units')
band = (100.0, 1500.0)

variants = {
    'global floor, double (current)': lr.envelope_global,
    'local floor, double': lr.envelope_local,
    'whitened (per-bin), double': lr.envelope_whitened,
}
# thresholds: current detector uses 4/8 dB; the adaptive ones use 6/10
cfg = {'global floor, double (current)': (wp.P['low_db'], wp.P['high_db']),
       'local floor, double': (lr.LP['low_snr'], lr.LP['high_snr']),
       'whitened (per-bin), double': (lr.LP['low_snr'], lr.LP['high_snr'])}
print(f"{'detector':34s} found  P     R     F1    frameJ  onset  offset")
rows = {}
for name, fn in variants.items():
    t, e = fn(y, fs, band)
    lo, hi = cfg[name]
    det = lr.detect_envelope(t, e, lo, hi)
    r, mt = wp.evaluate(det, gt)
    f = wp.frame_level_eval(det, gt, dur)
    rows[name] = (det, r)
    print(f"{name:34s} {len(det):4d}  {r['precision']:.2f}  {r['recall']:.2f}  {r['f1']:.2f}   {f['jaccard']:.2f}   "
          f"{r['onset_err_ms']:4.0f}   {r['offset_err_ms']:4.0f}")

# per-section recall for the global vs whitened detector
snrs = (20, 12, 6, 15, 8, 20, 10, 5)
sec = dur / len(snrs)
print('\nper-section F1 (section SNR):')
for name in ('global floor, double (current)', 'whitened (per-bin), double'):
    det = rows[name][0]; out = []
    for i, s in enumerate(snrs):
        a, b = i * sec, (i + 1) * sec
        g = gt[(gt[:, 0] >= a) & (gt[:, 1] < b)]
        d = det[(det[:, 0] >= a) & (det[:, 1] < b)]
        out.append(f"{s}dB:{wp.evaluate(d, g)[0]['f1']:.2f}")
    print(f'  {name:34s}', ' '.join(out))

# label-free analysis of units found by the whitened detector
det = rows['whitened (per-bin), double'][0]
r, mt = wp.evaluate(det, gt)
R = wp.unit_representations(y, fs, det)
print('\nlabel-free analysis of the', len(det), 'detected units:')
for n in R:
    D = wp.distance_matrix(n, R[n])
    k = wp.choose_k(D, 2, 8)[0]
    lab = wp.cluster(D, k)
    st = lr.cluster_stability(n, R[n], k)
    print(f'  {n:20s} auto k={k}  bootstrap stability ARI={st[0]:.2f}+-{st[1]:.2f}')
n = 'mfcc_mean_std_dur'
D = wp.distance_matrix(n, R[n]); k = wp.choose_k(D, 2, 8)[0]; lab = wp.cluster(D, k)
prof, chance = lr.repetition_profile(lab, 20)
top = np.argsort(prof)[::-1][:3] + 1
print('  repetition profile peaks at lags (units):', list(top), ' values', np.round(prof[top - 1], 2),
      ' chance ~', np.round(chance[top - 1], 2))

# sequence-level check on the matched units: symbol string of detected clusters vs annotated types
# (annotated order, detections in time order). Edit distance counts a missed unit as ONE error,
# whereas comparing position by position would shift every later symbol (Pace's "frame shift").
gt_seq = list(gt[:, 2].astype(int))
det_lab = np.full(len(det), -1); det_lab[:] = lab
det_seq = list(det_lab)
# map each detected cluster to the annotated type it overlaps most (majority vote on matched units)
from collections import Counter
mp = {}
for c in set(det_seq):
    votes = Counter(int(gt[j, 2]) for i, j in mt if det_lab[i] == c)
    mp[c] = votes.most_common(1)[0][0] if votes else -1
mapped = [mp[c] for c in det_seq]
pos = np.mean([a == b for a, b in zip(mapped, gt_seq)])
print(f'  sequence-level: edit distance (normalised) = {lr.sequence_edit_distance(mapped, gt_seq):.3f};'
      f' position-by-position agreement = {pos:.3f}')
