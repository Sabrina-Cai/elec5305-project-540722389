"""
Preliminary humpback-song segmentation + unit-similarity pipeline (Python mirror of the MATLAB code).

Purpose: run here to get first numbers while the MATLAB version is the project deliverable.
Parameters are kept identical to matlab/params.m.

NOTE: results on SYNTHETIC data only test the pipeline mechanics (known ground truth).
They say nothing about performance on real humpback recordings.
"""
import numpy as np
from scipy import signal
from scipy.fft import dct
from scipy.ndimage import uniform_filter1d
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import pdist, squareform

# ----------------------------------------------------------------- parameters
P = dict(
    fs=8000,
    bp_lo=80.0, bp_hi=3500.0,          # pre-processing band-pass (Hz)
    nfft=512, hop=80,                  # STFT: 64 ms window, 10 ms hop at 8 kHz
    smooth_s=0.10,                     # envelope smoothing (s)
    floor_pct=20,                      # noise floor = this percentile of envelope (dB)
    low_db=4.0, high_db=8.0,           # double-threshold offsets above floor (dB)
    single_db=6.0,                     # single-threshold offset (baseline detector)
    min_dur=0.25, min_gap=0.10,        # post-processing (s)
    narrow_band=(100.0, 1500.0),       # band for band-limited detector (Hz)
    n_mels=26, n_mfcc=12, mfcc_fmin=50.0, mfcc_fmax=3500.0,
    n_spec_frames=40,                  # time-normalised spectrogram width for correlation measure
    iou_thr=0.5,
)

# ----------------------------------------------------------------- synthetic song
def _unit(kind, fs, rng):
    jit = rng.uniform(0.92, 1.08)
    if kind == 0:   # A: up-sweep with 3 harmonics
        d = 0.9 * jit; t = np.arange(int(d * fs)) / fs
        f = np.linspace(200, 500, t.size); harm = [1, .6, .3]
    elif kind == 1:  # B: down-sweep
        d = 1.1 * jit; t = np.arange(int(d * fs)) / fs
        f = np.linspace(800, 300, t.size); harm = [1, .5]
    elif kind == 2:  # C: low tonal unit with vibrato
        d = 1.4 * jit; t = np.arange(int(d * fs)) / fs
        f = 150 + 15 * np.sin(2 * np.pi * 4 * t); harm = [1, .7, .5, .3]
    else:            # D: pulsed band-limited noise
        d = 0.5 * jit; t = np.arange(int(d * fs)) / fs
        b, a = signal.butter(4, [300, 1200], 'bandpass', fs=fs)
        x = signal.lfilter(b, a, rng.standard_normal(t.size))
        x *= 0.5 * (1 + np.sin(2 * np.pi * 15 * t))
        x /= np.max(np.abs(x))
        return x * signal.windows.tukey(t.size, 0.3)
    ph = 2 * np.pi * np.cumsum(f) / fs
    x = sum(h * np.sin((k + 1) * ph) for k, h in enumerate(harm))
    return x / np.max(np.abs(x)) * signal.windows.tukey(t.size, 0.3)


def _pink(n, rng):
    w = rng.standard_normal(n)
    b = [0.049922035, -0.095993537, 0.050612699, -0.004408786]
    a = [1, -2.494956002, 2.017265875, -0.522189400]
    return signal.lfilter(b, a, w)


def gen_synthetic_song(snr_db=10.0, seed=0, fs=8000):
    """Return x, gt (N x 3 array: onset_s, offset_s, type), themes layout."""
    rng = np.random.default_rng(seed)
    theme1, theme2 = [0, 1, 0, 2], [3, 3, 2, 1]
    song = theme1 * 0
    layout = [theme1] * 4 + [theme2] * 3 + [theme1] * 3
    pieces, gt, t_cur = [], [], 1.0
    pieces.append(np.zeros(int(t_cur * fs)))
    for ti, theme in enumerate(layout):
        for k in theme:
            u = _unit(k, fs, rng)
            gt.append((t_cur, t_cur + u.size / fs, k))
            pieces.append(u)
            gap = rng.uniform(0.3, 0.6)
            pieces.append(np.zeros(int(gap * fs))); t_cur += u.size / fs + gap
        pieces.append(np.zeros(int(0.8 * fs))); t_cur += 0.8
    s = np.concatenate(pieces)
    active = np.abs(s) > 1e-6
    noise = _pink(s.size, rng)
    noise *= np.sqrt(np.mean(s[active] ** 2) / 10 ** (snr_db / 10) / np.mean(noise ** 2))
    n_std = noise.std()
    tt = np.arange(s.size) / fs
    ship = 2 * n_std * np.sin(2 * np.pi * 40 * tt) * (0.6 + 0.4 * np.sin(2 * np.pi * tt / 20))
    clicks = np.zeros_like(s)
    for c in rng.uniform(2, tt[-1] - 2, 8):
        i = int(c * fs); clicks[i:i + 40] += 4 * n_std * rng.standard_normal(40)
    x = s + noise + ship + clicks
    x /= 1.05 * np.max(np.abs(x))
    return x, np.array(gt)

# ----------------------------------------------------------------- pre-processing
def preprocess(x, fs, lo=None, hi=None):
    lo = P['bp_lo'] if lo is None else lo
    hi = P['bp_hi'] if hi is None else hi
    sos = signal.butter(4, [lo, hi], 'bandpass', fs=fs, output='sos')
    y = signal.sosfiltfilt(sos, x)
    return y / np.max(np.abs(y))


def band_envelope_db(x, fs, band):
    f, t, S = signal.spectrogram(x, fs, window='hann', nperseg=P['nfft'],
                                 noverlap=P['nfft'] - P['hop'], mode='psd')
    m = (f >= band[0]) & (f <= band[1])
    e = 10 * np.log10(S[m].sum(axis=0) + 1e-12)
    n = max(1, int(round(P['smooth_s'] * fs / P['hop'])))
    return t, uniform_filter1d(e, n, mode='nearest')

# ----------------------------------------------------------------- detectors
def _runs(mask):
    d = np.diff(np.r_[0, mask.astype(int), 0])
    return np.flatnonzero(d == 1), np.flatnonzero(d == -1) - 1


def _postprocess(starts, ends, t):
    segs = [[t[s], t[e]] for s, e in zip(starts, ends)]
    merged = []
    for s in segs:
        if merged and s[0] - merged[-1][1] < P['min_gap']:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    return np.array([m for m in merged if m[1] - m[0] >= P['min_dur']]).reshape(-1, 2)


def detect(x, fs, method='double', band=None):
    """method: 'single' | 'double'. band=(lo,hi) Hz for the envelope (default: full pre-processing band)."""
    band = band or (P['bp_lo'], P['bp_hi'])
    t, e = band_envelope_db(x, fs, band)
    floor = np.percentile(e, P['floor_pct'])
    if method == 'single':
        s, en = _runs(e > floor + P['single_db'])
    else:
        lo_thr, hi_thr = floor + P['low_db'], floor + P['high_db']
        s, en = _runs(e > lo_thr)
        keep = [i for i, (a, b) in enumerate(zip(s, en)) if np.any(e[a:b + 1] > hi_thr)]
        s, en = s[keep], en[keep]
    return _postprocess(s, en, t), (t, e, floor)

# ----------------------------------------------------------------- evaluation
def iou(a, b):
    inter = max(0.0, min(a[1], b[1]) - max(a[0], b[0]))
    return inter / ((a[1] - a[0]) + (b[1] - b[0]) - inter + 1e-12)


def evaluate(det, gt, thr=None):
    """One-to-one greedy matching by IoU. gt: (N,>=2). Returns dict + list of (det_idx, gt_idx)."""
    thr = P['iou_thr'] if thr is None else thr
    pairs = sorted(((iou(d, g[:2]), i, j) for i, d in enumerate(det) for j, g in enumerate(gt)), reverse=True)
    ud, ug, match = set(), set(), []
    for v, i, j in pairs:
        if v < thr: break
        if i in ud or j in ug: continue
        ud.add(i); ug.add(j); match.append((i, j))
    tp = len(match); fp = len(det) - tp; fn = len(gt) - tp
    prec = tp / max(1, tp + fp); rec = tp / max(1, tp + fn)
    f1 = 2 * prec * rec / max(1e-12, prec + rec)
    on = [abs(det[i][0] - gt[j][0]) * 1000 for i, j in match]
    off = [abs(det[i][1] - gt[j][1]) * 1000 for i, j in match]
    return dict(tp=tp, fp=fp, fn=fn, precision=prec, recall=rec, f1=f1,
                onset_err_ms=float(np.mean(on)) if on else np.nan,
                offset_err_ms=float(np.mean(off)) if off else np.nan), match

# ----------------------------------------------------------------- features
def _mel_fb(fs, nfft, n_mels, fmin, fmax):
    mel = lambda f: 2595 * np.log10(1 + f / 700)
    imel = lambda m: 700 * (10 ** (m / 2595) - 1)
    pts = imel(np.linspace(mel(fmin), mel(fmax), n_mels + 2))
    bins = np.floor((nfft + 1) * pts / fs).astype(int)
    fb = np.zeros((n_mels, nfft // 2 + 1))
    for m in range(1, n_mels + 1):
        l, c, r = bins[m - 1], bins[m], bins[m + 1]
        for k in range(l, c): fb[m - 1, k] = (k - l) / max(1, c - l)
        for k in range(c, r): fb[m - 1, k] = (r - k) / max(1, r - c)
    return fb


def mfcc_frames(seg, fs):
    win, hop = 200, 80  # 25 ms / 10 ms
    seg = np.append(seg[0], seg[1:] - 0.97 * seg[:-1])
    if seg.size < win: seg = np.pad(seg, (0, win - seg.size))
    n = 1 + (seg.size - win) // hop
    fr = np.stack([seg[i * hop:i * hop + win] * np.hamming(win) for i in range(n)])
    pw = np.abs(np.fft.rfft(fr, P['nfft'], axis=1)) ** 2
    lm = np.log(pw @ _mel_fb(fs, P['nfft'], P['n_mels'], P['mfcc_fmin'], P['mfcc_fmax']).T + 1e-10)
    return dct(lm, type=2, norm='ortho', axis=1)[:, 1:P['n_mfcc'] + 1]


def unit_representations(x, fs, segs):
    """Return dict of feature matrices (n_units x d) keyed by representation name."""
    f, t, S = signal.spectrogram(x, fs, window='hann', nperseg=P['nfft'], noverlap=P['nfft'] - P['hop'])
    band = (f >= 80) & (f <= 2000)
    L = 10 * np.log10(S[band] + 1e-12)
    mean_mfcc, mfcc_stat, cent, spec = [], [], [], []
    for a, b in segs:
        seg = x[int(a * fs):int(b * fs)]
        M = mfcc_frames(seg, fs)
        mean_mfcc.append(M.mean(0))
        mfcc_stat.append(np.r_[M.mean(0), M.std(0), np.log(b - a)])
        i0, i1 = np.searchsorted(t, a), max(np.searchsorted(t, b), np.searchsorted(t, a) + 2)
        U = L[:, i0:i1]
        pw = 10 ** (U / 10)
        fb = f[band][:, None]
        c = (pw * fb).sum(0) / pw.sum(0)
        bw = np.sqrt((pw * (fb - c) ** 2).sum(0) / pw.sum(0))
        cent.append([c.mean(), c.std(), bw.mean(), np.log(b - a)])
        xi = np.linspace(0, 1, U.shape[1]); xo = np.linspace(0, 1, P['n_spec_frames'])
        R = np.stack([np.interp(xo, xi, row) for row in U])
        R = R - R.mean()
        spec.append(R.ravel())
    z = lambda A: (A - A.mean(0)) / (A.std(0) + 1e-9)
    return dict(mfcc_mean=z(np.array(mean_mfcc)), mfcc_mean_std_dur=z(np.array(mfcc_stat)),
                centroid_bw_dur=z(np.array(cent)), spec_corr=np.array(spec))


def distance_matrix(name, F):
    return squareform(pdist(F, 'correlation')) if name == 'spec_corr' else squareform(pdist(F, 'euclidean'))


def cluster(D, k):
    Z = linkage(squareform(D, checks=False), 'average')
    return fcluster(Z, k, 'maxclust') - 1


def ari(a, b):
    a = np.asarray(a); b = np.asarray(b)
    ca, cb = np.unique(a), np.unique(b)
    C = np.array([[np.sum((a == i) & (b == j)) for j in cb] for i in ca])
    c2 = lambda v: v * (v - 1) / 2
    s = c2(C).sum(); sa = c2(C.sum(1)).sum(); sb = c2(C.sum(0)).sum(); n = c2(C.sum())
    exp = sa * sb / n; mx = 0.5 * (sa + sb)
    return (s - exp) / (mx - exp) if mx != exp else 1.0


def top_ngrams(seq, n=4, top=3):
    from collections import Counter
    c = Counter(tuple(seq[i:i + n]) for i in range(len(seq) - n + 1))
    return c.most_common(top)
