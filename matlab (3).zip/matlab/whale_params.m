function P = whale_params()
%PARAMS  All tunable parameters in one place (identical to python/whale_pipeline.py).
P.fs          = 8000;          % working sample rate (Hz); real files are resampled to this
P.bp          = [80 3500];     % pre-processing band-pass (Hz)
P.nfft        = 512;           % STFT window length (64 ms at 8 kHz)
P.hop         = 80;            % STFT hop (10 ms)
P.smooth_s    = 0.05;          % envelope smoothing (s)
P.floor_pct   = 20;            % noise floor = this percentile of the dB envelope
P.low_db      = 10;             % double-threshold: low  threshold above floor (dB)
P.high_db     = 14;             % double-threshold: high threshold above floor (dB)
P.single_db   = 6;             % single-threshold baseline detector (dB above floor)
P.min_dur     = 0.25;          % discard detections shorter than this (s)
P.min_gap     = 0.10;          % merge detections closer than this (s)
P.narrow_band = [100 1500];    % band for the band-limited detector (Hz)
P.n_mels      = 26;            % mel filters
P.n_mfcc      = 12;            % MFCCs kept (c1..c12, c0 dropped)
P.mfcc_fmin   = 50;            % mel filterbank range (Hz)
P.mfcc_fmax   = 3500;
P.n_spec_frames = 40;          % time-normalised width for spectrogram-correlation measure
P.iou_thr     = 0.5;           % IoU needed to count a detection as correct
end
