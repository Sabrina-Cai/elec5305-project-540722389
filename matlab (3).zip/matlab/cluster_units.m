function [labels, Dm] = cluster_units(F, name, k)
%CLUSTER_UNITS  Average-linkage hierarchical clustering of unit descriptors.
%   Needs Statistics and Machine Learning Toolbox (pdist, linkage, cluster).
if strcmp(name, 'spec_corr'), dist = 'correlation'; else, dist = 'euclidean'; end
d  = pdist(F, dist);
Dm = squareform(d);
labels = cluster(linkage(d, 'average'), 'maxclust', k);
end
