%% RUN_LONG_RECORDING  Analyse the long (25 min) humpback recording.
% Needs the functions in matlab/ (your existing code) AND this folder on the MATLAB path:
%     addpath('matlab'); addpath('matlab_long');
% Needs Signal Processing + Statistics and Machine Learning toolboxes.
% NOTE: not run by the author - report any error message.
%
% Steps
%   1  read the file in chunks, resample to 8 kHz, band-pass
%   2  detect units with an adaptive noise floor (method below), save units CSV
%   3  pick windows to annotate (first time) / score the detectors on them (afterwards)
%   4  describe every detected unit, cluster (k from silhouette), check stability, repetition
% Why an adaptive floor: Pace (2013, Sec. 9.2) says the main weakness of the double-threshold
% detector is that thresholds must be set by hand for each recording, and suggests
% pre-whitening. In a 25 min file the noise level changes, so one global floor cannot fit.
clear; clc; close all
annotFile ='nips4b_annotations_no4.csv'
wavFile   = 'NIPS4B_Humpback_Darewin.wav';   % <- EDIT: your file name (the Explorer name is cut off)
annotFile = 'nips4b_annotations.csv';        % made by annotate_units (absolute seconds)
winFile   = 'eval_windows.csv';              % windows to annotate / evaluate
method    = 'whitened';                      % 'global' | 'local' | 'whitened'
descriptor = 'mfcc_mean_std_dur';            % descriptor used for the unit sequence analysis

P = params_long();
band = P.narrow_band;

%% 1 read
tic; [y, P] = read_long_audio(wavFile, P, 60);
y = preprocess_song(y, P.fs, P.bp);
dur = numel(y) / P.fs;
fprintf('Read %s: %.1f min at %d Hz  (%.0f s)\n', wavFile, dur/60, P.fs, toc);

%% 2 detect
[t, e] = adaptive_envelope(y, P.fs, band, P, method);
segs = detect_on_envelope(t, e, P.low_snr, P.high_snr, P);
fprintf('%s detector (%d/%d dB): %d units, median length %.2f s, %.0f%% of the file\n', method, ...
    P.low_snr, P.high_snr, size(segs, 1), median(diff(segs, 1, 2)), 100 * sum(diff(segs, 1, 2)) / dur);
writematrix(segs, 'units_detected.csv');
upm = histcounts(segs(:, 1), 0:60:ceil(dur/60)*60);
figure('Name', 'Units per minute'); bar(upm); xlabel('minute of recording'); ylabel('units detected');
title('Song activity over the recording (a dip can mean the singer moved away)');

%% 3 annotate / evaluate
didEval = false;
if ~isfile(winFile)
    W = select_eval_windows(dur, P.n_eval_win, P.eval_win_s, 1);
    writematrix(W, winFile);
    fprintf('\nWindows chosen for annotation (saved to %s):\n', winFile);
    for i = 1:size(W, 1)
        idx = t >= W(i,1) & t <= W(i,2);
        fprintf('  %d: %4d-%4d s   (%.0f%% of frames above the low threshold)\n', i, W(i,1), W(i,2), 100*mean(e(idx) > P.low_snr));
    end
    fprintf(['\nAnnotate them one at a time with the click tool (use your written unit rule, from the\n' ...
        'plain spectrogram, not the detector output):\n  annotate_units(''%s'', ''%s'', [start end])\n' ...
        'Windows with almost no song (a low %% above) are not useful - re-run select_eval_windows\n' ...
        'with another seed. The first %d windows are used to TUNE thresholds, the rest to TEST.\n\n'], ...
        wavFile, annotFile, P.n_tune_win);
elseif isfile(annotFile)
    didEval = true;
    W0 = readmatrix(winFile);  gtAll = readmatrix(annotFile);
    % use only windows that actually contain annotations (>= 5 units)
    cnt = arrayfun(@(i) sum(gtAll(:,1) >= W0(i,1) & gtAll(:,2) <= W0(i,2)), 1:size(W0, 1));
    W = W0(cnt >= 5, :);
    if isempty(W), error('No window in %s has >= 5 annotated units.', winFile); end
    if size(W, 1) == 1       % only one annotated window: first half tunes, second half tests
        mid = mean(W);  W = [W(1) mid; mid W(2)];
        fprintf(['Only one window is annotated: its first half is used to tune thresholds and its\n' ...
                 'second half to test them (less independent than separate windows).\n']);
    end
    nT = min(P.n_tune_win, max(1, floor(size(W, 1) / 2)));  tuneIdx = 1:nT;  testIdx = nT+1:size(W, 1);
    fprintf('\nEvaluation: %d tuning windows, %d test windows, %d annotated units in total\n', ...
        numel(tuneIdx), numel(testIdx), size(gtAll, 1));
    methods = {'global', 'local', 'whitened'};
    fprintf('%-10s | %-9s | found miss false |  P    R    F1  | frameJ | onset offset (ms)\n', 'floor', 'thr');
    for m = 1:3
        [tm, em] = adaptive_envelope(y, P.fs, band, P, methods{m});
        lo = P.low_snr; hi = P.high_snr;
        if m == 1, lo = P.low_db; hi = P.high_db; end            % global uses your own settings
        if ~isempty(tuneIdx)                                      % tune on the tuning windows only
            best = -1;
            for lo_c = [1 2 3 4 6 8]
                for hi_c = [5 6 8 10 12 14]
                    if hi_c < lo_c + 2, continue; end
                    sc = score_windows(detect_on_envelope(tm, em, lo_c, hi_c, P), gtAll, W(tuneIdx, :));
                    if sc.frameJ > best, best = sc.frameJ; lo = lo_c; hi = hi_c; end
                end
            end
        end
        r = score_windows(detect_on_envelope(tm, em, lo, hi, P), gtAll, W(testIdx, :));
        fprintf('%-10s | %2d / %-2d dB | %5d %4d %5d | %.2f %.2f %.2f | %.2f   | %5.0f %5.0f\n', methods{m}, ...
            lo, hi, r.found, r.fn, r.fp, r.precision, r.recall, r.f1, r.frameJ, r.on, r.off);
    end
    fprintf('(thresholds tuned on the tuning windows; scores are on the TEST windows only)\n');
end

%% 4 characterise all detected units
R = unit_features_long(y, P.fs, segs, P);
names = fieldnames(R);
bout = [1; 1 + cumsum(segs(2:end, 1) - segs(1:end-1, 2) > P.bout_gap_s)];
fprintf('\n%d units in %d song bouts. Label-free clustering of ALL units:\n', size(segs, 1), max(bout));
fprintf('%-20s | auto k | silhouette | bootstrap stability (ARI)\n', 'descriptor');
for i = 1:numel(names)
    [~, Dm] = cluster_units(R.(names{i}), names{i}, 2);
    [k, s] = choose_k(Dm, 2, 12);
    [ms, ss] = cluster_stability(R.(names{i}), names{i}, k);
    fprintf('%-20s | %6d | %10.2f | %.2f +- %.2f\n', names{i}, k, s, ms, ss);
end
[~, Dm] = cluster_units(R.(descriptor), descriptor, 2);
k = choose_k(Dm, 2, 12);
lab = cluster_units(R.(descriptor), descriptor, k);
[prof, chance] = repetition_profile(lab, 40, bout);
[pk, lag] = max(prof(2:end)); lag = lag + 1;
fprintf('\nUsing %s with k = %d. Strongest repetition lag: %d units (%.2f same label vs %.2f chance)\n', ...
    descriptor, k, lag, pk, chance(lag));

figure('Name', 'Repetition'); plot(1:40, prof, 'o-', 1:40, chance, '--');
xlabel('lag (units)'); ylabel('P(same cluster L units later)'); legend('data', 'shuffled', 'Location', 'best');
title('Repetition of the unit sequence');
figure('Name', 'Recurrence'); n0 = min(150, numel(lab));
imagesc(lab(1:n0) == lab(1:n0).'); colormap(gray); axis image
xlabel('unit #'); ylabel('unit #'); title('Same-cluster matrix of the first units (diagonal stripes = repetition)');
figure('Name', 'Unit atlas'); nb = size(R.spec_corr, 2) / P.n_spec_frames;
tiledlayout('flow', 'TileSpacing', 'compact');
for c = 1:k
    nexttile; imagesc(reshape(mean(R.spec_corr(lab == c, :), 1), nb, P.n_spec_frames)); axis xy
    title(sprintf('cluster %d (n=%d)', c, nnz(lab == c))); set(gca, 'XTick', [], 'YTick', []);
end
sgtitle('Average spectrogram of each cluster (80-2000 Hz, time normalised)');

%% 5 sequence-level score on the TEST windows (needs annotations with a type column)
if didEval && size(gtAll, 2) >= 3 && ~isempty(testIdx)
    segsT = detect_on_envelope(t, e, P.low_snr, P.high_snr, P);   % same segs as above, indices match lab
    votes = zeros(k, max(gtAll(:, 3)));
    mt = cell(numel(testIdx), 1); di = cell(numel(testIdx), 1); gi = cell(numel(testIdx), 1);
    for q = 1:numel(testIdx)
        w = W(testIdx(q), :);
        di{q} = find(segsT(:, 1) >= w(1) & segsT(:, 2) <= w(2));
        gi{q} = find(gtAll(:, 1) >= w(1) & gtAll(:, 2) <= w(2));
        if isempty(di{q}) || isempty(gi{q}), continue; end
        [~, mt{q}] = evaluate_segmentation(segsT(di{q}, :), gtAll(gi{q}, :), P.iou_thr);
        for r = 1:size(mt{q}, 1)
            votes(lab(di{q}(mt{q}(r, 1))), gtAll(gi{q}(mt{q}(r, 2)), 3)) = votes(lab(di{q}(mt{q}(r, 1))), gtAll(gi{q}(mt{q}(r, 2)), 3)) + 1;
        end
    end
    [~, map] = max(votes, [], 2);                    % cluster -> annotated type (EVALUATION ONLY)
    fprintf('\nSequence-level score on test windows (cluster mapped to its majority annotated type):\n');
    for q = 1:numel(testIdx)
        if isempty(di{q}) || isempty(gi{q}), continue; end
        pred = map(lab(di{q})); truth = gtAll(gi{q}, 3);
        n = min(numel(pred), numel(truth));
        fprintf('  window %d: %d detected vs %d annotated units; edit distance %.2f; position-by-position agreement %.2f\n', ...
            testIdx(q), numel(pred), numel(truth), edit_distance_seq(pred, truth), mean(pred(1:n) == truth(1:n)));
    end
end

%% local helper
function r = score_windows(segs, gtAll, W)
%SCORE_WINDOWS  Pooled IoU + frame-level scores of detections vs annotations over some windows.
tp = 0; fp = 0; fn = 0; nd = 0; fj = []; on = []; off = [];
for q = 1:size(W, 1)
    a = W(q, 1); b = W(q, 2);
    d = segs(segs(:, 1) >= a & segs(:, 2) <= b, 1:2) - a;
    g = gtAll(gtAll(:, 1) >= a & gtAll(:, 2) <= b, 1:2) - a;
    if isempty(g), continue; end
    res = evaluate_segmentation(d, g, 0.5);
    f = frame_level_eval(d, g, b - a);
    tp = tp + res.tp; fp = fp + res.fp; fn = fn + res.fn; nd = nd + size(d, 1);
    fj(end+1) = f.jaccard; %#ok<AGROW>
    if res.tp > 0, on(end+1) = res.onset_err_ms; off(end+1) = res.offset_err_ms; end %#ok<AGROW>
end
r.found = nd; r.tp = tp; r.fp = fp; r.fn = fn;
r.precision = tp / max(1, tp + fp); r.recall = tp / max(1, tp + fn);
r.f1 = 2 * r.precision * r.recall / max(eps, r.precision + r.recall);
r.frameJ = mean(fj); if isempty(fj), r.frameJ = 0; end
r.on = mean(on); r.off = mean(off);
if isempty(on), r.on = NaN; r.off = NaN; end
end
