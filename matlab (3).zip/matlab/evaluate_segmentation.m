function [res, match] = evaluate_segmentation(det, gt, thr)
%EVALUATE_SEGMENTATION  Score detections against annotated units.
%   det, gt : N x 2 [onset offset] in seconds (gt may have extra columns, ignored)
%   A detection is correct (TP) if it overlaps an annotated unit with IoU >= thr;
%   matching is one-to-one, greedy by descending IoU.
%   res   : struct with tp, fp (false detections), fn (missed), precision, recall,
%           f1, onset_err_ms, offset_err_ms (mean absolute timing error of matches)
%   match : M x 2 [detection index, annotation index]
gt = gt(:, 1:2);
nd = size(det, 1); ng = size(gt, 1);
IoU = zeros(nd, ng);
for i = 1:nd
    for j = 1:ng
        inter = max(0, min(det(i,2), gt(j,2)) - max(det(i,1), gt(j,1)));
        IoU(i,j) = inter / ((det(i,2)-det(i,1)) + (gt(j,2)-gt(j,1)) - inter + eps);
    end
end
[v, order] = sort(IoU(:), 'descend');
usedD = false(nd, 1); usedG = false(ng, 1); match = zeros(0, 2);
for k = 1:numel(order)
    if v(k) < thr, break; end
    [i, j] = ind2sub([nd ng], order(k));
    if usedD(i) || usedG(j), continue; end
    usedD(i) = true; usedG(j) = true; match(end+1, :) = [i j]; %#ok<AGROW>
end
tp = size(match, 1); fp = nd - tp; fn = ng - tp;
res.tp = tp; res.fp = fp; res.fn = fn;
res.precision = tp / max(1, tp + fp);
res.recall    = tp / max(1, tp + fn);
res.f1 = 2 * res.precision * res.recall / max(eps, res.precision + res.recall);
if tp > 0
    res.onset_err_ms  = 1000 * mean(abs(det(match(:,1),1) - gt(match(:,2),1)));
    res.offset_err_ms = 1000 * mean(abs(det(match(:,1),2) - gt(match(:,2),2)));
else
    res.onset_err_ms = NaN; res.offset_err_ms = NaN;
end
end
