%% RUN_BASELINE  Baseline segmentation + unit-similarity experiment on ONE recording.
% Default input is the synthetic test song (known ground truth). To use a real
% recording, point wavFile at it and gtFile at your hand-made annotation CSV
% (columns: onset_s, offset_s, [type]); set gtFile = '' if you have none yet.
clear; clc; close all
here = fileparts(mfilename('fullpath'));
wavFile = fullfile(here, '..', 'results', 'synth_snr10.wav');
gtFile  = fullfile(here, '..', 'results', 'synth_snr10_gt.csv');

P = whale_params();
[x, P] = load_song(wavFile, P);
y = preprocess_song(x, P.fs, P.bp);

%% 1. Segment (double-threshold, band-limited)
[segs, info] = detect_units(y, P.fs, 'double', P.narrow_band, P);
fprintf('Detected %d units\n', size(segs, 1));

%% 2. Evaluate against annotations
haveGT = ~isempty(gtFile) && isfile(gtFile);
if haveGT
    gt = readmatrix(gtFile);                         % onset, offset, (type)
    [res, match] = evaluate_segmentation(segs, gt, P.iou_thr);
    fprintf('TP %d  FP %d  FN %d | precision %.3f recall %.3f F1 %.3f\n', ...
        res.tp, res.fp, res.fn, res.precision, res.recall, res.f1);
    fprintf('Mean |onset error| %.1f ms, |offset error| %.1f ms\n', res.onset_err_ms, res.offset_err_ms);
end

%% 3. Figure: spectrogram + detections + envelope with thresholds
win = hann(P.nfft, 'periodic');
[S, f, t] = spectrogram(y, win, P.nfft - P.hop, P.nfft, P.fs);
figure('Position', [100 100 1000 700]);
ax1 = subplot(2, 1, 1);
imagesc(t, f, 10*log10(abs(S).^2 + 1e-12)); axis xy; ylim([0 2500]); colormap(ax1, parula);
ylabel('Frequency (Hz)'); title('Spectrogram with detected (orange) and annotated (white) units'); hold on
for i = 1:size(segs, 1), plot(segs(i,1:2), [2200 2200], 'Color', [0.9 0.62 0], 'LineWidth', 4); end
if haveGT, for i = 1:size(gt, 1), plot(gt(i,1:2), [2380 2380], 'w', 'LineWidth', 4); end, end
ax2 = subplot(2, 1, 2);
plot(info.t, info.e, 'LineWidth', 1); hold on
yline(info.floorDb, ':k', 'noise floor'); yline(info.lowThr, '--g', 'low'); yline(info.highThr, '--r', 'high');
xlabel('Time (s)'); ylabel('Band energy (dB)'); linkaxes([ax1 ax2], 'x'); grid on

%% 4. Unit similarity: which description groups units by type best?
if haveGT && size(gt, 2) >= 3 && size(match, 1) >= 8
    di = match(:, 1); truth = gt(match(:, 2), 3);
    R  = unit_representations(y, P.fs, segs(di, :), P);
    names = fieldnames(R); k = numel(unique(truth));
    fprintf('\nClustering agreement with true unit type (ARI, k = %d):\n', k);
    for n = 1:numel(names)
        lab = cluster_units(R.(names{n}), names{n}, k);
        fprintf('  %-20s %.3f\n', names{n}, adjusted_rand(lab, truth));
    end
    % similarity matrices, units sorted by true type
    [~, idx] = sort(truth);
    figure('Position', [100 100 900 400]);
    for n = 1:2
        nm = {'mfcc_mean_std_dur', 'spec_corr'}; [~, Dm] = cluster_units(R.(nm{n}), nm{n}, k);
        subplot(1, 2, n); imagesc(Dm(idx, idx)); axis square; colorbar; title(strrep(nm{n}, '_', ' '));
    end
end
