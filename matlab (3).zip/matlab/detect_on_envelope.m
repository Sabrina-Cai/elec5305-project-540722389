function segs = detect_on_envelope(t, e, low, high, P)
%DETECT_ON_ENVELOPE  Double-threshold (hysteresis) detection on an envelope already in dB
%   above the noise floor. A region where e > low is kept only if e > high somewhere in it.
%   Close detections are merged (P.min_gap) and short ones dropped (P.min_dur).
%   segs : N x 2 [onset offset] in seconds
d = diff([0; double(e(:) > low); 0]);
s = find(d == 1); en = find(d == -1) - 1;
keep = false(size(s));
for i = 1:numel(s), keep(i) = any(e(s(i):en(i)) > high); end
s = s(keep); en = en(keep);
segs = zeros(0, 2);
if isempty(s), return; end
raw = [t(s), t(en)];
merged = raw(1, :);
for i = 2:size(raw, 1)
    if raw(i, 1) - merged(end, 2) < P.min_gap, merged(end, 2) = raw(i, 2);
    else, merged(end+1, :) = raw(i, :); end %#ok<AGROW>
end
segs = merged((merged(:, 2) - merged(:, 1)) >= P.min_dur, :);
end
