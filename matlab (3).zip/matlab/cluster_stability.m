function [m, s] = cluster_stability(F, name, k, reps, frac)
%CLUSTER_STABILITY  How stable is a clustering, WITHOUT any annotations?
%   Re-clusters random subsets (default 80%) of the units into k clusters and compares each
%   result with the clustering of all units on the shared units (adjusted Rand index).
%   m, s : mean and std over reps.  1 = perfectly stable, 0 = no better than chance.
%   Needs Statistics and Machine Learning Toolbox.
if nargin < 4, reps = 30; end
if nargin < 5, frac = 0.8; end
rng(0);
[full, Dm] = cluster_units(F, name, k);
n = size(F, 1); sc = zeros(reps, 1);
for r = 1:reps
    idx = sort(randperm(n, round(frac * n)));
    Z = linkage(squareform(Dm(idx, idx), 'tovector'), 'average');
    sc(r) = adjusted_rand(cluster(Z, 'maxclust', k), full(idx));
end
m = mean(sc); s = std(sc);
end
