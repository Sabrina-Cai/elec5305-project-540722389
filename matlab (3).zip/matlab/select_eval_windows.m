function W = select_eval_windows(dur, nwin, win_s, seed)
%SELECT_EVAL_WINDOWS  Pick nwin windows (win_s long) spread over the recording at random.
%   One random window per equal-sized stretch of the file, so the test covers the whole
%   recording instead of just the parts you happened to look at. Returns [start end] in s.
if nargin < 4, seed = 1; end
rng(seed);
edges = linspace(0, dur - win_s, nwin + 1);
W = zeros(nwin, 2);
for i = 1:nwin
    a = edges(i) + rand * (edges(i+1) - edges(i));
    W(i, :) = round([a, a + win_s]);
end
end
