function [x, P] = read_long_audio(wavFile, P, chunk_s)
%READ_LONG_AUDIO  Read a long recording in chunks and resample it to P.fs.
%   Avoids holding the whole 44.1 kHz file (25 min = 68 M samples) as doubles at once.
%   Chunks overlap by 0.5 s while resampling so there are no edge glitches.
%   NOTE: not run by the author - report any error message.
if nargin < 3, chunk_s = 60; end
info = audioinfo(wavFile);
fs0 = info.SampleRate; N = info.TotalSamples;
if fs0 < P.fs, P.fs = fs0; P.bp(2) = min(P.bp(2), 0.45 * fs0); end
[p, q] = rat(P.fs / fs0);                       % e.g. 44100 -> 8000 gives p/q = 80/441
step = q * max(1, round(chunk_s * fs0 / q));    % chunk length, a multiple of q
pad  = q * max(1, round(0.5 * fs0 / q));        % overlap on each side, a multiple of q
out = {};
for a = 1:step:N
    i0 = max(1, a - pad); i1 = min(N, a + step - 1 + pad);
    seg = audioread(wavFile, [i0 i1]);
    seg = double(seg(:, 1));
    r = resample(seg, p, q);
    lead  = (a - i0) * p / q;                   % samples of left overlap after resampling
    n_out = floor(min(step, N - a + 1) * p / q);
    r = r(lead + 1 : min(numel(r), lead + n_out));
    out{end+1} = single(r); %#ok<AGROW>
end
x = double(vertcat(out{:}));
end
