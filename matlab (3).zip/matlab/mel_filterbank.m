function fb = mel_filterbank(fs, nfft, n_mels, fmin, fmax)
%MEL_FILTERBANK  Triangular mel filterbank (n_mels x nfft/2+1).
mel  = @(f) 2595 * log10(1 + f / 700);
imel = @(m) 700 * (10.^(m / 2595) - 1);
pts  = imel(linspace(mel(fmin), mel(fmax), n_mels + 2));
bins = floor((nfft + 1) * pts / fs);                 % 0-based FFT bin indices
fb = zeros(n_mels, nfft/2 + 1);
for m = 1:n_mels
    l = bins(m); c = bins(m+1); r = bins(m+2);
    for k = l:c-1, fb(m, k+1) = (k - l) / max(1, c - l); end
    for k = c:r-1, fb(m, k+1) = (r - k) / max(1, r - c); end
end
end
