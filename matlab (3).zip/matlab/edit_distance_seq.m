function d = edit_distance_seq(a, b)
%EDIT_DISTANCE_SEQ  Normalised Levenshtein distance between two symbol sequences (0 = identical).
%   A missed or extra unit costs ONE edit. Comparing position by position would instead shift
%   every later symbol by one place (the "frame-shift" error described in Pace 2013 Sec. 4.4).
a = a(:); b = b(:); na = numel(a); nb = numel(b);
D = zeros(na + 1, nb + 1); D(:, 1) = 0:na; D(1, :) = 0:nb;
for i = 1:na
    for j = 1:nb
        D(i+1, j+1) = min([D(i, j+1) + 1, D(i+1, j) + 1, D(i, j) + (a(i) ~= b(j))]);
    end
end
d = D(end, end) / max([na nb 1]);
end
