function [prof, chance] = repetition_profile(lab, maxLag, bout)
%REPETITION_PROFILE  How often does the unit type repeat L units later?
%   prof(L)   = fraction of unit pairs (i, i+L) with the same cluster label
%   chance(L) = the same for randomly shuffled labels (what you get with no structure)
%   A peak well above chance at lag L means the sequence repeats every L units (phrase / theme).
%   bout (optional) : bout id of each unit; pairs that straddle two bouts are ignored.
lab = lab(:); n = numel(lab);
if nargin < 3 || isempty(bout), bout = ones(n, 1); end
rng(0);
prof = nan(maxLag, 1); chance = nan(maxLag, 1);
sh = zeros(n, 50);
for r = 1:50, sh(:, r) = lab(randperm(n)); end
for L = 1:maxLag
    if n <= L, continue; end
    ok = bout(1:n-L) == bout(L+1:n);
    if ~any(ok), continue; end
    prof(L) = sum((lab(1:n-L) == lab(L+1:n)) & ok) / sum(ok);
    chance(L) = mean(mean((sh(1:n-L, :) == sh(L+1:n, :)) & ok, 1) * numel(ok) / sum(ok));
end
end
