function r = frame_level_eval(det, gt, dur, step)
%FRAME_LEVEL_EVAL  Score detections against annotations frame by frame.
%   det, gt : N x 2 [onset offset] in seconds (extra columns ignored)
%   dur     : length of the analysed signal (s)
%   step    : frame size in seconds (default 0.01)
%
%   One-to-one IoU matching (evaluate_segmentation) counts a unit that is split
%   into two pieces, or merged with its neighbour, as a miss AND a false detection.
%   Frame-level scoring does not:
%     precision = fraction of DETECTED time that is annotated
%     recall    = fraction of ANNOTATED time that is detected
%     jaccard   = |detected & annotated| / |detected | annotated|
%   Use both: IoU matching answers "did it find each unit", frame level answers
%   "how well does the detected time line up with the annotated time".
%   (Python twin: frame_level_eval in python/whale_pipeline.py, which was tested.)
%   NOTE: MATLAB version not run by the author - report any error message.
if nargin < 4, step = 0.01; end
n = ceil(dur / step);
t = ((0:n-1) + 0.5) * step;
D = false(1, n); G = false(1, n);
for i = 1:size(det, 1), D = D | (t >= det(i,1) & t < det(i,2)); end
for i = 1:size(gt, 1),  G = G | (t >= gt(i,1)  & t < gt(i,2));  end
inter = nnz(D & G); uni = nnz(D | G);
r.precision = inter / max(1, nnz(D));
r.recall    = inter / max(1, nnz(G));
r.f1        = 2 * r.precision * r.recall / max(eps, r.precision + r.recall);
r.jaccard   = inter / max(1, uni);
end
