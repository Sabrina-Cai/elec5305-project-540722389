function R = unit_features_long(y, fs, segs, P)
%UNIT_FEATURES_LONG  Same four descriptors as unit_representations, but computed unit by unit
%   (one small spectrogram per unit), so thousands of units from a 25 min file fit in memory.
%   z-scoring is done over ALL units at the end.
%   NOTE: not run by the author - report any error message.
win = hann(P.nfft, 'periodic');
n = size(segs, 1);
A = zeros(n, P.n_mfcc); B = zeros(n, 2*P.n_mfcc + 1); C = zeros(n, 4); D = [];
for k = 1:n
    a = segs(k, 1); b = segs(k, 2);
    seg = y(max(1, round(a*fs) + 1) : min(numel(y), round(b*fs)));
    M = mfcc_frames(seg, fs, P);
    A(k, :) = mean(M, 1);
    B(k, :) = [mean(M, 1), std(M, 1, 1), log(b - a)];
    [S, f] = spectrogram(seg(:), win, P.nfft - P.hop, P.nfft, fs);
    band = f >= 80 & f <= 2000;
    U  = 10 * log10(abs(S(band, :)).^2 + 1e-12);
    if size(U, 2) < 2, U = [U U]; end
    pw = 10 .^ (U / 10); fb = f(band);
    c  = sum(pw .* fb, 1) ./ sum(pw, 1);
    bw = sqrt(sum(pw .* (fb - c).^2, 1) ./ sum(pw, 1));
    C(k, :) = [mean(c), std(c, 1), mean(bw), log(b - a)];
    xi = linspace(0, 1, size(U, 2)); xo = linspace(0, 1, P.n_spec_frames);
    Rm = interp1(xi, U.', xo).';
    Rm = Rm - mean(Rm(:));
    if isempty(D), D = zeros(n, numel(Rm)); end
    D(k, :) = Rm(:).';
end
z = @(X) (X - mean(X, 1)) ./ (std(X, 1, 1) + 1e-9);
R.mfcc_mean = z(A); R.mfcc_mean_std_dur = z(B); R.centroid_bw_dur = z(C); R.spec_corr = D;
end
