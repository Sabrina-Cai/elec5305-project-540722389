%% RUN_SNR_COMPARISON  Single vs double threshold vs band-limited double threshold, across SNR.
% Uses the four synthetic files exported to ../results (SNR 20, 10, 5, 0 dB).
clear; clc; close all
here = fileparts(mfilename('fullpath'));
P = whale_params();
snrs = [20 10 5 0];
cfg  = {'single', [];  'double', [];  'double', P.narrow_band};
labels = {'single (broadband)', 'double (broadband)', 'double (100-1500 Hz)'};
F1 = zeros(numel(snrs), size(cfg, 1));
fprintf('%-6s %-24s %6s %6s %6s %8s %8s\n', 'SNR', 'detector', 'prec', 'rec', 'F1', 'on(ms)', 'off(ms)');
for i = 1:numel(snrs)
    base = fullfile(here, '..', 'results', sprintf('synth_snr%02d', snrs(i)));
    [x, Pi] = load_song([base '.wav'], P);
    y  = preprocess_song(x, Pi.fs, Pi.bp);
    gt = readmatrix([base '_gt.csv']);
    for j = 1:size(cfg, 1)
        segs = detect_units(y, Pi.fs, cfg{j, 1}, cfg{j, 2}, Pi);
        r = evaluate_segmentation(segs, gt, Pi.iou_thr);
        F1(i, j) = r.f1;
        fprintf('%-6d %-24s %6.3f %6.3f %6.3f %8.1f %8.1f\n', snrs(i), labels{j}, ...
            r.precision, r.recall, r.f1, r.onset_err_ms, r.offset_err_ms);
    end
end
figure; plot(snrs, F1, '-o', 'LineWidth', 1.5); set(gca, 'XDir', 'reverse'); grid on
xlabel('SNR (dB)'); ylabel('Segmentation F1 (IoU \geq 0.5)'); legend(labels, 'Location', 'southwest');
title('Detector comparison (synthetic song, seed 0)');
