function s = silhouette_from_dist(D, labels)
%SILHOUETTE_FROM_DIST  Mean silhouette value from a precomputed distance matrix.
%   D      : n x n symmetric distance matrix
%   labels : cluster assignment of each unit
%   About 1 = tight, well separated clusters; about 0 = overlapping; < 0 = mixed up.
%   Needs no annotations, so it can be used to choose the number of clusters.
%   (Python twin tested against scikit-learn.)  NOTE: MATLAB version not run by the author.
labels = labels(:);
n  = numel(labels);
ks = unique(labels);
if numel(ks) < 2, s = NaN; return; end
si = zeros(n, 1);
for i = 1:n
    same = labels == labels(i); same(i) = false;
    if ~any(same), continue; end                   % singleton cluster: silhouette 0
    a = mean(D(i, same));
    b = inf;
    for k = ks.'
        if k == labels(i), continue; end
        b = min(b, mean(D(i, labels == k)));
    end
    den = max(a, b);
    if den > 0, si(i) = (b - a) / den; end
end
s = mean(si);
end
