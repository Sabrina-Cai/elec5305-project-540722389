function [segs, info] = detect_units(x, fs, method, band, P)
%DETECT_UNITS  Energy-based unit detector.
%   method : 'single' - one threshold (simple baseline)
%            'double' - double-threshold (hysteresis) detector in the spirit of
%                       Pace et al. (2010): a region is kept only if it exceeds the
%                       HIGH threshold somewhere, and its edges are extended out to
%                       where the envelope falls below the LOW threshold.
%   band   : [lo hi] Hz used for the energy envelope ([] = full pre-processing band)
%   segs   : N x 2 matrix [onset offset] in seconds
%   NOTE: this is a re-implementation from the published description, NOT Pace's code.
%         Replace/compare with her MATLAB code once obtained.
if isempty(band), band = P.bp; end
[t, e] = band_envelope_db(x, fs, band, P);
es = sort(e);
floorDb = es(max(1, round(P.floor_pct / 100 * numel(es))));

switch method
    case 'single'
        [s, en] = find_runs(e > floorDb + P.single_db);
    case 'double'
        [s, en] = find_runs(e > floorDb + P.low_db);
        keep = false(size(s));
        for i = 1:numel(s)
            keep(i) = any(e(s(i):en(i)) > floorDb + P.high_db);
        end
        s = s(keep); en = en(keep);
    otherwise
        error('method must be ''single'' or ''double''');
end

segs = zeros(0, 2);
if ~isempty(s)
    raw = [t(s(:)), t(en(:))];
    merged = raw(1, :);
    for i = 2:size(raw, 1)                        % merge close detections
        if raw(i, 1) - merged(end, 2) < P.min_gap
            merged(end, 2) = raw(i, 2);
        else
            merged(end + 1, :) = raw(i, :); %#ok<AGROW>
        end
    end
    segs = merged((merged(:, 2) - merged(:, 1)) >= P.min_dur, :);   % drop short ones
end
info.t = t; info.e = e; info.floorDb = floorDb;
info.lowThr = floorDb + P.low_db; info.highThr = floorDb + P.high_db;
end

function [s, en] = find_runs(mask)
d  = diff([0, mask(:).', 0]);
s  = find(d == 1);
en = find(d == -1) - 1;
end
