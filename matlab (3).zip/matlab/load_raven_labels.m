function [arr, names] = load_raven_labels(path)
%LOAD_RAVEN_LABELS  Read a Raven selection table (tab-separated .txt).
%   Needs the columns 'Begin Time (s)', 'End Time (s)' and 'Type'.
%   arr   : N x 3 [onset_s, offset_s, type_id]  (same layout as annotate_units output)
%   names : cell array of type names, so names{type_id} is the original label
%   Lets you use annotations made in Raven (or exported from Audacity/Sonic
%   Visualiser in the same layout), including the 5,470 hand labels of a humpback
%   song session published with the MBARI hbwsc repository (its audio file is not
%   in the repository, so those labels cannot be used until you have that audio).
%   NOTE: MATLAB version not run by the author - report any error message.
opts = detectImportOptions(path, 'FileType', 'text', 'Delimiter', '\t', ...
    'VariableNamingRule', 'preserve');
opts = setvartype(opts, 'Type', 'string');
T   = readtable(path, opts);
on  = T.("Begin Time (s)");
off = T.("End Time (s)");
typ = strtrim(string(T.Type));
[u, ~, id] = unique(typ);
arr   = [on, off, id];
names = cellstr(u);
end
