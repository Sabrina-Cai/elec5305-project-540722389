%% MAKE_WHALE2_FIGURE  Clean figures + the missing numbers for the 16 s clip (whale2).
% Needs your existing functions, plot_detections_vs_annotations.m, and whale_params.m.
% Makes two pictures (iteration 1 and iteration 2 detections drawn against your annotations)
% and prints the scores for BOTH iterations, including the frame-level scores.
% NOTE: not run by the author in MATLAB - report any error message.
clear; close all
wavFile = 'whale2.wav'; annotFile = 'whale2_annotations.csv';
P = whale_params();
[x, P] = load_song(wavFile, P);
y = preprocess_song(x, P.fs, P.bp);
dur = numel(y) / P.fs;
gt = readmatrix(annotFile);                         % onset, offset, type

P1 = P; P1.low_db = 4; P1.high_db = 8; P1.smooth_s = 0.10;   % iteration 1 settings
P2 = P;                                                      % iteration 2 = your tuned params
runs = {'Iteration 1 (4/8 dB, smoothing 0.10 s)', P1; 'Iteration 2 (10/14 dB, smoothing 0.05 s)', P2};

fprintf('%-42s | found miss false |  P    R    F1  | onset offset | frame P   R    J\n', 'band-limited double threshold');
for k = 1:2
    s = detect_units(y, P.fs, 'double', P.narrow_band, runs{k, 2});
    [r, ~] = evaluate_segmentation(s, gt, P.iou_thr);
    f = frame_level_eval(s, gt, dur);
    fprintf('%-42s | %5d %4d %5d | %.2f %.2f %.2f | %5.0f %5.0f  | %.2f %.2f %.2f\n', runs{k, 1}, ...
        size(s, 1), r.fn, r.fp, r.precision, r.recall, r.f1, r.onset_err_ms, r.offset_err_ms, ...
        f.precision, f.recall, f.jaccard);
    plot_detections_vs_annotations(y, P.fs, s, gt, [0 dur], 3500);
    title(runs{k, 1});
    exportgraphics(gcf, sprintf('whale2_iter%d.png', k), 'Resolution', 200);
end
disp('Saved whale2_iter1.png and whale2_iter2.png - send them to me with the printed table.');
