function M = mfcc_frames(seg, fs, P)
%MFCC_FRAMES  Frame-wise MFCCs (c1..c12) of one unit; 25 ms Hamming / 10 ms hop.
%   Hand-written so that it matches the Python mirror exactly. Audio Toolbox's
%   mfcc() is a drop-in alternative once you want to compare against it.
win = 200; hop = 80;
seg = seg(:);
seg = [seg(1); seg(2:end) - 0.97 * seg(1:end-1)];     % pre-emphasis
if numel(seg) < win, seg(end+1:win) = 0; end
n  = 1 + floor((numel(seg) - win) / hop);
w  = hamming(win);
fb = mel_filterbank(fs, P.nfft, P.n_mels, P.mfcc_fmin, P.mfcc_fmax);
M  = zeros(n, P.n_mfcc);
for i = 1:n
    fr = seg((i-1)*hop + (1:win)) .* w;
    X  = abs(fft(fr, P.nfft)).^2;
    X  = X(1:P.nfft/2 + 1);
    c  = dct(log(fb * X + 1e-10));                     % orthonormal DCT-II
    M(i, :) = c(2:P.n_mfcc + 1).';
end
end
