function r = score_windows(segs, gtAll, W)
%SCORE_WINDOWS  Pooled IoU + frame-level scores of detections vs annotations over some windows.
%   segs  : N x 2 [onset offset] (s)      gtAll : annotations [onset offset type] (s)
%   W     : K x 2 windows [start end] (s). Only units fully inside a window are counted.
%   Same function as the one at the end of run_long_recording, here as its own file so you can
%   call it from the Command Window.
tp = 0; fp = 0; fn = 0; nd = 0; fj = []; on = []; off = [];
for q = 1:size(W, 1)
    a = W(q, 1); b = W(q, 2);
    d = segs(segs(:, 1) >= a & segs(:, 2) <= b, 1:2) - a;
    g = gtAll(gtAll(:, 1) >= a & gtAll(:, 2) <= b, 1:2) - a;
    if isempty(g), continue; end
    res = evaluate_segmentation(d, g, 0.5);
    f = frame_level_eval(d, g, b - a);
    tp = tp + res.tp; fp = fp + res.fp; fn = fn + res.fn; nd = nd + size(d, 1);
    fj(end+1) = f.jaccard; %#ok<AGROW>
    if res.tp > 0, on(end+1) = res.onset_err_ms; off(end+1) = res.offset_err_ms; end %#ok<AGROW>
end
r.found = nd; r.tp = tp; r.fp = fp; r.fn = fn;
r.precision = tp / max(1, tp + fp); r.recall = tp / max(1, tp + fn);
r.f1 = 2 * r.precision * r.recall / max(eps, r.precision + r.recall);
r.frameJ = mean(fj); if isempty(fj), r.frameJ = 0; end
r.on = mean(on); r.off = mean(off);
if isempty(on), r.on = NaN; r.off = NaN; end
end
