function plot_detections_vs_annotations(y, fs, segs, gt, tr, fmax)
%PLOT_DETECTIONS_VS_ANNOTATIONS  Cleaned spectrogram with detections (cyan, top) and your
%   annotations (white, bottom, with type number) for one time range.
%   plot_detections_vs_annotations(y, P.fs, segs, gtAll, [524 554])
%   Use it to see which annotated units were missed and which detections were false.
%   NOTE: not run by the author in MATLAB - report any error message.
if nargin < 6, fmax = 2000; end
i0 = max(1, round(tr(1) * fs) + 1); i1 = min(numel(y), round(tr(2) * fs));
x = y(i0:i1); t0 = (i0 - 1) / fs;
nwin = round(0.1 * fs); hop = round(0.01 * fs); nfft = 2^nextpow2(nwin);
[S, f, t] = spectrogram(x, hann(nwin), nwin - hop, nfft, fs);
m = f <= fmax;
L = 10 * log10(abs(S(m, :)).^2 + 1e-12);
L = L - median(L, 2); L = L - median(L, 1);
L = conv2(L, ones(9, 5) / 45, 'same');
v = sort(L(:));
figure('Position', [40 80 1400 600]);
imagesc(t + t0, f(m) / 1000, L); axis xy; colormap(hot); clim([v(round(0.70*numel(v))) v(round(0.998*numel(v)))]);
xlabel('Time (s)'); ylabel('Frequency (kHz)'); hold on
ym = fmax / 1000;
for i = 1:size(segs, 1)
    if segs(i, 2) < tr(1) || segs(i, 1) > tr(2), continue; end
    rectangle('Position', [segs(i,1) 0.88*ym segs(i,2)-segs(i,1) 0.10*ym], 'EdgeColor', 'c', 'LineWidth', 1.5);
end
for i = 1:size(gt, 1)
    if gt(i, 2) < tr(1) || gt(i, 1) > tr(2), continue; end
    rectangle('Position', [gt(i,1) 0.01*ym gt(i,2)-gt(i,1) 0.10*ym], 'EdgeColor', 'w', 'LineWidth', 1.5);
    if size(gt, 2) >= 3, text(mean(gt(i,1:2)), 0.06*ym, num2str(gt(i,3)), 'Color', 'w', 'HorizontalAlignment', 'center'); end
end
title('cyan = detected units (top)    white = annotated units (bottom, number = type)');
end
