function R = unit_representations(y, fs, segs, P)
%UNIT_REPRESENTATIONS  Four ways of describing each detected unit (one row per unit).
%   R.mfcc_mean          mean of c1..c12                           (z-scored)
%   R.mfcc_mean_std_dur  mean + std of c1..c12 + log duration       (z-scored)
%   R.centroid_bw_dur    spectral centroid mean/std, bandwidth, log duration (z-scored)
%   R.spec_corr          time-normalised log-spectrogram (80-2000 Hz), flattened
%                        (use correlation distance)
win = hann(P.nfft, 'periodic');
[S, f, t] = spectrogram(y(:), win, P.nfft - P.hop, P.nfft, fs);
band = f >= 80 & f <= 2000;
L  = 10 * log10(abs(S(band, :)).^2 + 1e-12);
fb = f(band);
n  = size(segs, 1);
A = zeros(n, P.n_mfcc); B = zeros(n, 2*P.n_mfcc + 1); C = zeros(n, 4);
D = zeros(n, nnz(band) * P.n_spec_frames);
for k = 1:n
    a = segs(k, 1); b = segs(k, 2);
    seg = y(max(1, round(a*fs) + 1) : min(numel(y), round(b*fs)));
    M = mfcc_frames(seg, fs, P);
    A(k, :) = mean(M, 1);
    B(k, :) = [mean(M, 1), std(M, 1, 1), log(b - a)];

    i0 = find(t >= a, 1, 'first'); if isempty(i0), i0 = numel(t) - 2; end
    i1 = find(t >= b, 1, 'first'); if isempty(i1), i1 = numel(t) + 1; end
    i1 = min(max(i1, i0 + 2), numel(t) + 1);
    U  = L(:, i0:i1-1);
    pw = 10 .^ (U / 10);
    c  = sum(pw .* fb, 1) ./ sum(pw, 1);
    bw = sqrt(sum(pw .* (fb - c).^2, 1) ./ sum(pw, 1));
    C(k, :) = [mean(c), std(c, 1), mean(bw), log(b - a)];

    xi = linspace(0, 1, size(U, 2)); xo = linspace(0, 1, P.n_spec_frames);
    Rm = interp1(xi, U.', xo).';                       % freq x n_spec_frames
    Rm = Rm - mean(Rm(:));
    D(k, :) = Rm(:).';
end
z = @(X) (X - mean(X, 1)) ./ (std(X, 1, 1) + 1e-9);
R.mfcc_mean = z(A); R.mfcc_mean_std_dur = z(B); R.centroid_bw_dur = z(C); R.spec_corr = D;
end
