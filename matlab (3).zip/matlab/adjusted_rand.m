function r = adjusted_rand(a, b)
%ADJUSTED_RAND  Adjusted Rand index between two labelings (1 = identical, ~0 = chance).
a = a(:); b = b(:);
[~, ~, ia] = unique(a); [~, ~, ib] = unique(b);
C  = accumarray([ia ib], 1);
c2 = @(v) v .* (v - 1) / 2;
s  = sum(c2(C(:))); sa = sum(c2(sum(C, 2))); sb = sum(c2(sum(C, 1)));
n  = c2(sum(C(:)));
ex = sa * sb / n; mx = 0.5 * (sa + sb);
if mx == ex, r = 1; else, r = (s - ex) / (mx - ex); end
end
