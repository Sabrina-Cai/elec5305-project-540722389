function annotate_units_clear(wavFile, outFile, t_range, opts)
%ANNOTATE_UNITS_CLEAR  Click annotation on a CLEANER spectrogram, a few seconds at a time.
%
%   annotate_units_clear('NIPS4B_Humpback_Darewin.wav', 'nips4b_annotations.csv', [103 163])
%
%   What is different from annotate_units:
%     * shows 15 s at a time (opts.view_s) and moves on by itself, with 3 s overlap
%     * only 0-2 kHz (opts.fmax); most of the energy of the units is below that
%     * steady lines (hum, the constant 0.4 kHz tone) are removed: each frequency row has its
%       median over the view subtracted
%     * click streaks are suppressed: each time column has its median over frequency subtracted
%       (turn off with opts.declick = false if a broadband unit seems to vanish)
%     * light smoothing, and the colour scale starts above the noise, so only real structure is bright
%     * a time grid every 1 s, to read onsets and offsets
%   Annotation itself is the same as before. For each unit:
%     1. click ONSET   2. click OFFSET   3. press a number key 1-9 for the TYPE
%   At the onset step:  u = undo last unit,  Enter = finish this 15 s view (it saves, and the next
%   view opens),  q = save and quit completely.
%   Units already saved show as grey boxes, so you do not annotate them twice. A unit that runs off
%   the right edge: skip it, it will be fully visible in the next view (overlap).
%   Annotate from THIS picture, not from detector output. Use your written unit rule.
%   NOTE: not run by the author in MATLAB - report any error message.
if nargin < 4, opts = struct; end
d = struct('view_s', 15, 'overlap_s', 3, 'fmax', 2000, 'nwin_s', 0.1, 'declick', true);
for f = fieldnames(d).', if ~isfield(opts, f{1}), opts.(f{1}) = d.(f{1}); end, end
info = audioinfo(wavFile);
if nargin < 3 || isempty(t_range), t_range = [0 info.Duration]; end
a = t_range(1);
while a < t_range(2)
    b = min(a + opts.view_s, t_range(2));
    quitAll = annotate_view(wavFile, outFile, [a b], opts);
    if quitAll || b >= t_range(2), break; end
    a = b - opts.overlap_s;
end
disp('Finished.');
end

function quitAll = annotate_view(wavFile, outFile, tr, opts)
quitAll = false;
info = audioinfo(wavFile); fs = info.SampleRate;
i0 = max(1, round(tr(1) * fs) + 1); i1 = min(info.TotalSamples, round(tr(2) * fs));
x = audioread(wavFile, [i0 i1]); x = x(:, 1);
t0 = (i0 - 1) / fs;

nwin = round(opts.nwin_s * fs); hop = round(0.010 * fs); nfft = 2^nextpow2(nwin);
[S, f, t] = spectrogram(x, hann(nwin), nwin - hop, nfft, fs);
m = f <= opts.fmax;
L = 10 * log10(abs(S(m, :)).^2 + 1e-12);
L = L - median(L, 2);                              % remove steady lines (per frequency)
if opts.declick, L = L - median(L, 1); end         % remove broadband clicks (per time frame)
k = [1 2 1]' * [1 2 1] / 16; L = conv2(L, k, 'same');
v = sort(L(:)); lo = v(round(0.60 * numel(v))); hi = v(round(0.998 * numel(v)));

fig = figure('Name', 'Annotate units (clear)', 'Position', [40 60 1400 650]);
ax = axes(fig);
imagesc(ax, t + t0, f(m) / 1000, L); axis(ax, 'xy'); colormap(ax, hot); clim(ax, [lo hi]);
xlabel(ax, 'Time (s)'); ylabel(ax, 'Frequency (kHz)'); hold(ax, 'on');
set(ax, 'XTick', ceil(t0):1:floor(t0 + t(end)));
grid(ax, 'on'); ax.GridColor = [1 1 1]; ax.GridAlpha = 0.25;
ymax = opts.fmax / 1000;

existing = zeros(0, 3);
if isfile(outFile)
    existing = readmatrix(outFile);
    for i = 1:size(existing, 1)
        if existing(i, 2) < tr(1) || existing(i, 1) > tr(2), continue; end
        patch(ax, existing(i, [1 2 2 1]), [0 0 ymax ymax], [0.5 0.7 1], ...
            'FaceAlpha', 0.20, 'EdgeColor', [0.5 0.7 1], 'LineStyle', ':');
        text(ax, mean(existing(i, 1:2)), ymax * 0.96, num2str(existing(i, 3)), 'Color', [0.6 0.8 1], ...
            'HorizontalAlignment', 'center');
    end
end

units = zeros(0, 3); handles = {};
while true
    title(ax, sprintf('%.0f-%.0f s   Unit %d: click ONSET   (u = undo, Enter = next view, q = save and quit)', ...
        tr(1), tr(2), size(units, 1) + 1));
    [a, ~, b1] = ginput(1);
    if isempty(a), break; end
    if b1 == 113, quitAll = true; break; end        % q
    if b1 == 117                                    % u = undo
        if ~isempty(units)
            units(end, :) = []; delete(handles{end}); handles(end) = []; %#ok<AGROW>
        end
        continue
    end
    if b1 > 3, continue; end
    h1 = plot(ax, [a a], [0 ymax], 'c', 'LineWidth', 1.5);
    title(ax, sprintf('Unit %d: click OFFSET', size(units, 1) + 1));
    [b, ~, b2] = ginput(1);
    if isempty(b), delete(h1); break; end
    if b2 > 3, delete(h1); continue; end
    on = min(a, b); off = max(a, b);
    title(ax, 'Press a number key 1-9 for the unit TYPE (click = type 1)');
    [~, ~, kk] = ginput(1);
    if isempty(kk) || kk < 49 || kk > 57, type = 1; else, type = kk - 48; end
    delete(h1);
    hp = patch(ax, [on off off on], [0 0 ymax ymax], 'c', 'FaceAlpha', 0.20, 'EdgeColor', 'c', 'LineWidth', 1.2);
    ht = text(ax, (on + off) / 2, ymax * 0.96, num2str(type), 'Color', 'c', ...
        'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    handles{end + 1} = [hp; ht]; %#ok<AGROW>
    units(end + 1, :) = [on, off, type]; %#ok<AGROW>
end

if ~isempty(units)
    all = [existing; units];
    [~, order] = sort(all(:, 1)); all = all(order, :);
    writetable(array2table(all, 'VariableNames', {'onset_s', 'offset_s', 'type'}), outFile);
    fprintf('View %.0f-%.0f s: %d new units saved (%d in file)\n', tr(1), tr(2), size(units, 1), size(all, 1));
end
close(fig);
end