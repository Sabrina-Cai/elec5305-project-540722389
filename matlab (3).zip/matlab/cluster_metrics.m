function m = cluster_metrics(labels, truth)
%CLUSTER_METRICS  Agreement between a clustering and the annotated unit types.
%   labels : cluster assignment of each unit
%   truth  : annotated type of each unit (the "classes")
%   Returns a struct with
%     NMI           normalised mutual information (arithmetic-mean normalisation)
%     homogeneity   1 = every cluster contains units of ONE type only
%     completeness  1 = every type ends up in ONE cluster
%     V             harmonic mean of homogeneity and completeness
%     ARI           adjusted Rand index (1 = identical, about 0 = chance)
%   Why several scores: homogeneity and completeness show HOW a clustering is
%   wrong (types split across clusters vs different types mixed together),
%   which a single number hides.
%   (Python twin: cluster_metrics in python/whale_pipeline.py, tested against
%   scikit-learn to 1e-15.)  NOTE: MATLAB version not run by the author.
[~, ~, ic] = unique(truth(:));
[~, ~, ik] = unique(labels(:));
C   = accumarray([ic ik], 1);
Hc  = entropy_counts(sum(C, 2));
Hk  = entropy_counts(sum(C, 1));
Hck = entropy_counts(C(:));                       % joint entropy
mi  = Hc + Hk - Hck;
if Hc == 0, hom = 1; else, hom = 1 - (Hck - Hk) / Hc; end
if Hk == 0, com = 1; else, com = 1 - (Hck - Hc) / Hk; end
if hom + com == 0, v = 0; else, v = 2 * hom * com / (hom + com); end
meanH = 0.5 * (Hc + Hk);
if meanH == 0, nmi = 1; else, nmi = mi / meanH; end
m = struct('NMI', nmi, 'homogeneity', hom, 'completeness', com, 'V', v, ...
           'ARI', adjusted_rand(labels, truth));
end

function h = entropy_counts(c)
c = c(c > 0);
p = c / sum(c);
h = -sum(p .* log(p));
end
