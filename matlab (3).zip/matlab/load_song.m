function [x, P] = load_song(wavFile, P)
%LOAD_SONG  Read a recording (first channel) and resample to P.fs.
%   If the file's sample rate is too low for the 8 kHz working rate, P.fs and the
%   upper band-pass edge are reduced automatically.
[x, fs0] = audioread(wavFile);
x = x(:, 1);
if fs0 < P.fs
    P.fs = fs0;
    P.bp(2) = min(P.bp(2), 0.45 * fs0);
end
if fs0 ~= P.fs
    [p, q] = rat(P.fs / fs0);
    x = resample(x, p, q);                 % e.g. 44100 -> 8000 gives p/q = 80/441
end
end
