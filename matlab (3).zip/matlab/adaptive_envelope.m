function [t, e] = adaptive_envelope(x, fs, band, P, method)
%ADAPTIVE_ENVELOPE  Band envelope in dB ABOVE THE NOISE FLOOR, three ways to get the floor.
%   method 'global'   : one floor for the whole recording (= your current detector)
%          'local'    : the floor is a rolling low percentile of the dB envelope
%                       (window P.floor_win_s), so it follows slow changes in noise level
%          'whitened' : the power in EACH frequency bin is first divided by that bin's rolling
%                       floor (a simple pre-whitening, as suggested in Pace 2013 Sec. 9.2),
%                       so coloured noise / ship hum is flattened; then the in-band mean SNR
%   Thresholds are then in dB above 0 (the floor); no per-recording floor guess is needed.
%   NOTE: my own implementation from the thesis description; not run by the author in MATLAB.
[t, S] = band_spectrogram_blocks(x, fs, band, P);
fps = 1 / (t(2) - t(1));
n = max(1, round(P.smooth_s * fs / P.hop));
switch method
    case 'global'
        e = movmean(10 * log10(double(sum(S, 1)) + 1e-12), n);
        e = e - pct_of(e, P.floor_pct);
    case 'local'
        e = movmean(10 * log10(double(sum(S, 1)) + 1e-12), n);
        e = e - local_floor(e, fps, P.floor_win_s, P.floor_pct_local);
    case 'whitened'
        fl = local_floor(S, fps, P.floor_win_s, P.floor_pct_local);
        e = movmean(10 * log10(double(mean(S ./ (fl + 1e-20), 1)) + 1e-12), n);
        e = e - pct_of(e, 15);
    otherwise
        error('method must be global, local or whitened');
end
e = e(:);
end

function v = pct_of(e, pct)
s = sort(e(:)); v = s(max(1, round(pct / 100 * numel(s))));
end

function F = local_floor(A, fps, win_s, pct)
%LOCAL_FLOOR  Rolling low percentile along time (dim 2), on a coarse grid then interpolated.
n = size(A, 2);
step = max(1, round(win_s * fps / 4)); half = round(win_s * fps / 2);
c = 1:step:n; if c(end) ~= n, c(end+1) = n; end
V = zeros(size(A, 1), numel(c));
for j = 1:numel(c)
    w = sort(double(A(:, max(1, c(j) - half) : min(n, c(j) + half))), 2);
    V(:, j) = w(:, max(1, round(pct / 100 * size(w, 2))));
end
F = zeros(size(A));
for r = 1:size(A, 1)
    F(r, :) = interp1(c, V(r, :), 1:n, 'linear');
end
end
