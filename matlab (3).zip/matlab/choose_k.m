function [bestK, bestS] = choose_k(D, kmin, kmax)
%CHOOSE_K  Pick the number of clusters WITHOUT using the annotations.
%   Cuts an average-linkage dendrogram into k = kmin..kmax clusters and returns the k
%   with the best mean silhouette. Previously run_baseline.m gave the clustering the
%   true number of unit types, which quietly hands it the answer.
%   Needs Statistics and Machine Learning Toolbox (linkage, cluster, squareform).
%   NOTE: MATLAB version not run by the author - report any error message.
if nargin < 2, kmin = 2; end
if nargin < 3, kmax = 8; end
n = size(D, 1);
kmax = min(kmax, n - 1);
if kmax < kmin, bestK = min(kmin, n); bestS = NaN; return; end
Z = linkage(squareform(D, 'tovector'), 'average');
bestS = -2; bestK = kmin;
for k = kmin:kmax
    s = silhouette_from_dist(D, cluster(Z, 'maxclust', k));
    if s > bestS, bestS = s; bestK = k; end
end
end
