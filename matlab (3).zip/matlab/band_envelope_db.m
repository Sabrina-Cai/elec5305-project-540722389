function [t, e] = band_envelope_db(x, fs, band, P)
%BAND_ENVELOPE_DB  Smoothed band-limited energy envelope (dB) from the STFT.
win = hann(P.nfft, 'periodic');
[S, f, t] = spectrogram(x(:), win, P.nfft - P.hop, P.nfft, fs);
m = f >= band(1) & f <= band(2);
e = 10 * log10(sum(abs(S(m, :)).^2, 1) + 1e-12);    % 1 x frames
n = max(1, round(P.smooth_s * fs / P.hop));
e = movmean(e, n);
t = t(:);                                           % column of frame-centre times (s)
end
