%% RUN_EVALUATION  Fuller evaluation of the detectors and of the unit-similarity step.
% Replaces the evaluation part of run_real_data.m. Uses YOUR current params.m, so
% your tuned thresholds are kept. Reports, for each of three detectors:
%   (a) one-to-one IoU matching  -> found / missed / false, timing error
%   (b) frame-level scores       -> precision / recall / Jaccard of detected TIME
% (a) alone punishes a unit split in two (or merged) twice; (b) shows how well the
% detected time lines up. Then, for the matched units of the band-limited double
% threshold detector, it compares four unit descriptors by how well hierarchical
% clustering recovers your unit types:
%   - with k chosen WITHOUT the annotations (silhouette), and
%   - with k = number of true types (optimistic; shown for comparison only).
% Needs Statistics and Machine Learning Toolbox. Not run by the author - report errors.
clear; clc; close all

wavFile   = 'whale2.wav';                 % <- your recording
annotFile = 'whale2_annotations.csv';     % <- onset_s, offset_s, type (CSV from
                                          %    annotate_units) or a Raven .txt table
window_s  = [0 16];                       % analyse this slice (s) of the recording

P = whale_params();
[x, P] = load_song(wavFile, P);
x = x(max(1, round(window_s(1)*P.fs) + 1) : min(numel(x), round(window_s(2)*P.fs)));
dur = numel(x) / P.fs;
y = preprocess_song(x, P.fs, P.bp);

% annotations -> seconds relative to the start of the slice
if endsWith(annotFile, '.txt'), gt = load_raven_labels(annotFile); else, gt = readmatrix(annotFile); end
gt = gt(gt(:,2) > window_s(1) & gt(:,1) < window_s(2), :);
gt(:,1:2) = min(max(gt(:,1:2) - window_s(1), 0), dur);
fprintf('%d annotated units in the analysed slice\n\n', size(gt, 1));

variants = {'single', [];  'double', [];  'double', P.narrow_band};
names    = {'single (broadband)', 'double (broadband)', 'double (100-1500 Hz)'};
fprintf('%-22s | %5s %5s %5s | %5s %5s %5s %5s | %7s %7s\n', 'detector', 'found', 'miss', 'false', ...
    'P', 'R', 'F1', 'Jacc', 'on(ms)', 'off(ms)');
for j = 1:size(variants, 1)
    segs{j} = detect_units(y, P.fs, variants{j,1}, variants{j,2}, P); %#ok<SAGROW>
    [r, match{j}] = evaluate_segmentation(segs{j}, gt, P.iou_thr);   %#ok<SAGROW>
    f = frame_level_eval(segs{j}, gt, dur);
    fprintf('%-22s | %5d %5d %5d | %5.2f %5.2f %5.2f %5.2f | %7.0f %7.0f\n', names{j}, ...
        size(segs{j}, 1), r.fn, r.fp, f.precision, f.recall, f.f1, f.jaccard, r.onset_err_ms, r.offset_err_ms);
end
fprintf('(found/miss/false: IoU >= %.1f matching.  P R F1 Jacc: frame-level, 10 ms frames.)\n\n', P.iou_thr);

%% Unit similarity: which description recovers the unit types best?
di = match{3}(:, 1);                       % detections of the band-limited detector that matched
if size(gt, 2) >= 3 && numel(di) >= 8
    truth = gt(match{3}(:, 2), 3);
    kTrue = numel(unique(truth));
    R = unit_representations(y, P.fs, segs{3}(di, :), P);
    reps = fieldnames(R);
    fprintf('Clustering %d matched units (%d true types)\n', numel(di), kTrue);
    fprintf('%-20s | %-3s %-6s %-6s %-6s %-6s | %-6s (k = true types)\n', 'descriptor', 'k', 'NMI', 'homog', 'compl', 'ARI', 'ARI');
    for n = 1:numel(reps)
        [~, Dm] = cluster_units(R.(reps{n}), reps{n}, 2);      % only the distance matrix is used here
        k  = choose_k(Dm, 2, min(8, numel(di) - 1));
        lab = cluster_units(R.(reps{n}), reps{n}, k);
        m  = cluster_metrics(lab, truth);
        labT = cluster_units(R.(reps{n}), reps{n}, kTrue);
        fprintf('%-20s | %-3d %-6.3f %-6.3f %-6.3f %-6.3f | %-6.3f\n', reps{n}, k, m.NMI, ...
            m.homogeneity, m.completeness, m.ARI, adjusted_rand(labT, truth));
    end
    fprintf('Few units -> treat this as a pilot, not a result.\n');
else
    fprintf('Not enough matched, typed units (need >= 8 and a type column) for the clustering step.\n');
end
