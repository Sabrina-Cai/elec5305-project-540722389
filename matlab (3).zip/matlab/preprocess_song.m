function y = preprocess_song(x, fs, bp)
%PREPROCESS_SONG  Zero-phase Butterworth band-pass + peak normalisation.
%   Isolates the band where humpback units live and removes low-frequency
%   ship/flow noise (< bp(1)) and high-frequency noise (> bp(2)).
x = x(:);
[z, p, k] = butter(4, bp / (fs/2), 'bandpass');
[sos, g]  = zp2sos(z, p, k);
y = filtfilt(sos, g, x);
y = y / max(abs(y));
end
