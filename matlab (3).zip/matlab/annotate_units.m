function units = annotate_units(wavFile, outFile, t_range)
%ANNOTATE_UNITS  Click-based hand annotation of humpback units on a plain spectrogram.
%
%   annotate_units('whale2.wav', 'whale2_annotations.csv')
%   annotate_units('long.wav', 'long_annotations.csv', [0 30])   % annotate 0-30 s only
%
%   For each unit:
%     1. click its ONSET   (first visible energy)
%     2. click its OFFSET  (where it has faded)
%     3. press a number key 1-9 for the unit TYPE (a plain mouse click = type 1)
%   Keys at the onset step:  u = undo last unit,  Enter = finish and save.
%   If outFile already exists, new units are merged into it (so a long file can be
%   annotated in chunks with t_range). Times are absolute seconds in the file.
%
%   Output CSV columns: onset_s, offset_s, type  (same format as the synthetic
%   ground-truth files, so run_real_data.m / run_baseline.m can read it directly).
%
%   Annotate from this plain spectrogram, NOT from the detector output, so the
%   evaluation is not biased. Write down your unit definition first.
%   NOTE: not tested in MATLAB by the author - report any error message.

if nargin < 3, t_range = []; end
[x, fs] = audioread(wavFile);
x = x(:, 1);
t0 = 0;
if ~isempty(t_range)
    i0 = max(1, round(t_range(1) * fs) + 1);
    i1 = min(numel(x), round(t_range(2) * fs));
    x  = x(i0:i1);
    t0 = (i0 - 1) / fs;
end

% Spectrogram: 64 ms window, 10 ms hop (same time resolution as the detector)
nwin = round(0.064 * fs);
hop  = round(0.010 * fs);
[S, f, t] = spectrogram(x, hann(nwin), nwin - hop, nwin, fs);
fmax = min(3500, fs / 2);
m = f <= fmax;
L = 10 * log10(abs(S(m, :)).^2 + 1e-12);
v = sort(L(:));
lo = v(max(1, round(0.05 * numel(v))));
hi = v(round(0.999 * numel(v)));

fig = figure('Name', 'Annotate units', 'Position', [60 100 1300 600]);
ax = axes(fig);
imagesc(ax, t + t0, f(m) / 1000, L); axis(ax, 'xy'); colormap(ax, parula); clim(ax, [lo hi]);
xlabel(ax, 'Time (s)'); ylabel(ax, 'Frequency (kHz)'); hold(ax, 'on');
ymax = fmax / 1000;

% show units that already exist in the output file (grey boxes)
existing = zeros(0, 3);
if isfile(outFile)
    existing = readmatrix(outFile);
    for i = 1:size(existing, 1)
        patch(ax, existing(i, [1 2 2 1]), [0 0 ymax ymax], [0.7 0.7 0.7], ...
            'FaceAlpha', 0.12, 'EdgeColor', [0.7 0.7 0.7], 'LineStyle', ':');
    end
end

units = zeros(0, 3);
handles = {};
while true
    title(ax, sprintf('Unit %d: click ONSET     (u = undo last, Enter = finish and save)', size(units, 1) + 1));
    [a, ~, b1] = ginput(1);
    if isempty(a), break; end
    if b1 == 117                                   % 'u' = undo
        if ~isempty(units)
            units(end, :) = [];
            delete(handles{end}); handles(end) = []; %#ok<AGROW>
        end
        continue
    end
    if b1 > 3, continue; end                       % ignore other keys at this step

    h1 = plot(ax, [a a], [0 ymax], 'w', 'LineWidth', 1.5);
    title(ax, sprintf('Unit %d: click OFFSET', size(units, 1) + 1));
    [b, ~, b2] = ginput(1);
    if isempty(b), delete(h1); break; end
    if b2 > 3, delete(h1); continue; end           % key pressed instead of click: cancel this unit
    on = min(a, b); off = max(a, b);

    title(ax, 'Press a number key 1-9 for the unit TYPE (click = type 1)');
    [~, ~, k] = ginput(1);
    if isempty(k) || k < 49 || k > 57, type = 1; else, type = k - 48; end

    delete(h1);
    hp = patch(ax, [on off off on], [0 0 ymax ymax], 'w', 'FaceAlpha', 0.18, 'EdgeColor', 'w', 'LineWidth', 1.2);
    ht = text(ax, (on + off) / 2, ymax * 0.96, num2str(type), 'Color', 'w', ...
        'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    handles{end + 1} = [hp; ht]; %#ok<AGROW>
    units(end + 1, :) = [on, off, type]; %#ok<AGROW>
end

title(ax, sprintf('%d units annotated', size(units, 1)));
if isempty(units)
    disp('No units annotated; nothing saved.');
    return
end

all = [existing; units];
[~, order] = sort(all(:, 1));
all = all(order, :);
writetable(array2table(all, 'VariableNames', {'onset_s', 'offset_s', 'type'}), outFile);
fprintf('Saved %d units (%d new) to %s\n', size(all, 1), size(units, 1), outFile);
disp(array2table(all, 'VariableNames', {'onset_s', 'offset_s', 'type'}));
end
