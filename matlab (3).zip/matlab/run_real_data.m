%% RUN_REAL_DATA  Template for a real recording (NIPS4B humpback song, Watkins clips, ...)
% Workflow that keeps the evaluation honest:
%   1. Run this script with annotFile = '' to look at the spectrogram and tune P.
%   2. Annotate 30-50 consecutive units BY HAND from the spectrogram, independent of
%      the detector (Audacity / Raven / Sonic Visualiser label export -> CSV with
%      onset_s, offset_s). Don't "correct" the detector's output, or you bias the score.
%   3. Set annotFile and re-run to get missed / false detections and timing error.
clear; clc; close all
wavFile   = 'whale2.wav';   % file (NIPS4B is 44.1 kHz mono; resampled to 8 kHz)
annotFile = 'whale2_annotations.csv';                    % <- hand annotations CSV, or '' for none
window_s  = [0 16];               % analyse this slice of the recording (s), e.g. [0 120]

P = whale_params();
[x, P] = load_song(wavFile, P);
if ~isempty(window_s)
    x = x(max(1, round(window_s(1)*P.fs)+1) : min(numel(x), round(window_s(2)*P.fs)));
end
y = preprocess_song(x, P.fs, P.bp);

% Compare detectors
variants = {'single', [];  'double', [];  'double', P.narrow_band};
names    = {'single', 'double', 'double band-limited'};
for j = 1:size(variants, 1)
    segs{j} = detect_units(y, P.fs, variants{j, 1}, variants{j, 2}, P); %#ok<SAGROW>
    fprintf('%-22s %d units\n', names{j}, size(segs{j}, 1));
end
if ~isempty(annotFile)
    gt = readmatrix(annotFile);
    gt = gt(gt(:,1) >= window_s(1) & gt(:,2) <= window_s(2), :) - [window_s(1) window_s(1) zeros(1, size(gt,2)-2)];
    for j = 1:numel(segs)
        r = evaluate_segmentation(segs{j}, gt, P.iou_thr);
        fprintf('%-22s P %.3f R %.3f F1 %.3f | miss %d false %d | onset %.0f ms offset %.0f ms\n', ...
            names{j}, r.precision, r.recall, r.f1, r.fn, r.fp, r.onset_err_ms, r.offset_err_ms);
    end
end

% Look at the result
[~, info] = detect_units(y, P.fs, 'double', P.narrow_band, P);
[S, f, t] = spectrogram(y, hann(P.nfft, 'periodic'), P.nfft - P.hop, P.nfft, P.fs);
figure; imagesc(t, f, 10*log10(abs(S).^2 + 1e-12)); axis xy; ylim([0 3500]); hold on
s = segs{3}; for i = 1:size(s, 1), plot(s(i,:), [3300 3300], 'Color', [0.9 0.62 0], 'LineWidth', 4); end
xlabel('Time (s)'); ylabel('Frequency (Hz)'); title('Double-threshold, band-limited detections');
figure; plot(info.t, info.e); yline(info.lowThr, '--g'); yline(info.highThr, '--r'); grid on
xlabel('Time (s)'); ylabel('Band energy (dB)');

% Export detections as a CSV (useful for the extension / report tables)
writematrix([s(:,1), s(:,2)], 'detected_units.csv');
