function [t, S] = band_spectrogram_blocks(x, fs, band, P)
%BAND_SPECTROGRAM_BLOCKS  In-band STFT power for a long signal, computed block by block.
%   S : (bins in band) x frames, single-precision POWER;  t : frame-centre times (s).
%   Same window / hop as band_envelope_db, but never holds the full spectrogram in memory.
nfft = P.nfft; hop = P.hop;
win = hann(nfft, 'periodic');
f = (0:nfft/2).' * fs / nfft;
m = f >= band(1) & f <= band(2);
blk = hop * round(60 * fs / hop);               % samples per block (multiple of hop)
nfr = floor((numel(x) - nfft) / hop) + 1;       % total number of frames
S = zeros(nnz(m), nfr, 'single');
fr = 1;
while fr <= nfr
    s0 = (fr - 1) * hop;                        % 0-based first sample of this frame
    nb = min(blk / hop, nfr - fr + 1);          % frames in this block
    seg = x(s0 + 1 : s0 + (nb - 1) * hop + nfft);
    Sb = spectrogram(seg(:), win, nfft - hop, nfft, fs);
    S(:, fr:fr+nb-1) = single(abs(Sb(m, :)).^2);
    fr = fr + nb;
end
t = ((0:nfr-1).' * hop + nfft / 2) / fs;
end
